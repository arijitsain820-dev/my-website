# JMT Production — Design Brief

| Attribute | Value |
|-----------|-------|
| **Category** | Showcase / Studio Portfolio |
| **Tone** | Cinematic brutalism — dramatic, refined, unapologetically dark |
| **Aesthetic** | Luxury studio, premium creative, bold blacks with gold accents |
| **Target** | Clients seeking professional wedding, fashion, concert, and video production |

## Palette (OKLCH)

| Token | Role | L | C | H |
|-------|------|---|---|---|
| Background | Primary surface | 0.12 | 0 | — |
| Foreground | Text | 0.95 | 0 | — |
| Card | Content container | 0.15 | 0 | — |
| Accent | Gold/amber highlight | 0.55 | 0.20 | 45° |
| Primary (dark) | Interactive primary | 0.50 | 0.18 | 42° |
| Muted | Secondary text | 0.22 | 0 | — |
| Border | Divider | 0.22 | 0 | — |

## Typography

| Type | Font | Weight | Usage |
|------|------|--------|-------|
| Display | Fraunces | 600–700 | Hero, section headings, emotional copy |
| Body | DM Sans | 400–600 | Descriptions, paragraph text, UI labels |
| Mono | System | 400 | Technical, quotes (if needed) |

## Structural Zones

| Zone | Surface | Treatment | Height |
|------|---------|-----------|--------|
| Header | Card (0.15) | Fixed, border-b gold | 80px |
| Hero | Background (0.12) | Full-bleed portfolio image, overlay, serif headline | 70vh |
| Portfolio Grid | Background (0.12) | 2–4 col responsive, card containers, category tabs | Dynamic |
| Team Showcase | Card (0.15) | 4 member cards, circular images, serif names | 400px |
| Contact Section | Muted (0.22) | Large gold CTA, WhatsApp + phone buttons, inquiry form | 350px |
| Footer | Card (0.15) | Social links, copyright, border-t gold | 120px |

## Spacing & Rhythm

- **Grid**: 16px base unit (4–8–12–16–24–32–48px increments)
- **Density**: Open, cinematic breathing room; generous gutters between sections
- **Radius**: Minimal (4px on cards, 0 on hero); sharp edges reinforce brutalism

## Component Patterns

- **Portfolio cards**: Bordered, hover lift, gold accent line top (2px)
- **Team cards**: Circular photo, serif name, sand-colored role text
- **Buttons**: Gold background (accent), sans-serif 600wt, letter-spacing 0.5px, hover lift + shadow
- **Forms**: Dark input fields (0.18 bg), gold ring on focus, sans-serif labels
- **Tabs**: Underline accent style, sans-serif, uppercase letter-spacing

## Motion

- **Transition default**: all 0.3s cubic-bezier(0.4, 0, 0.2, 1)
- **Hover interactions**: Subtle lift (translateY -2px) + shadow deepening
- **Entrance**: Fade-in on portfolio cards; scale-in on team cards
- **Constraints**: No bounce, no bright glow effects — only cinematic fades and lifts

## Elevation & Depth

- **Layered approach**: Hero image with text overlay, card stack in portfolio, footer layered below content
- **Shadow hierarchy**: Minimal on cards (subtle 0 4px 12px), elevated on hover (0 12px 24px), cinematic on footer (0 20px 40px)
- **Accent framing**: Gold border-top on portfolio + contact sections; thin gold dividers between major zones

## Signature Detail

- **Gold accent line** framing portfolio section headers and CTA buttons; reinforces luxury studio aesthetic
- **Hero image integration**: Portfolio imagery dominates above fold, sets mood immediately
- **Serif + sans pairing**: Emotional serif headlines (Fraunces) paired with clean DM Sans for trust
- **Dark-first brand**: No light mode; committed to cinematic mood

## Constraints

- No color outside OKLCH palette; no raw hex or gradients beyond cinematic shadows
- No bouncy animations or glow effects
- Accessibility: AA+ contrast on all foreground-on-background; gold text >= 0.55 L on 0.12 background passes 4.5:1 ratio
- Responsive: Mobile-first grid; hero scales to device height; portfolio grid 1 col (mobile) → 2–3 col (tablet) → 3–4 col (desktop)

