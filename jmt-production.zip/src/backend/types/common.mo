module {
  public type Timestamp = Int;
  public type ServiceType = {
    #Wedding;
    #Fashion;
    #Concert;
    #Birthday;
    #VideoEditing;
    #SocialMedia;
  };
};
