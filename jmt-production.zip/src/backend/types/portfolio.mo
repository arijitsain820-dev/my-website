import Storage "mo:caffeineai-object-storage/Storage";
import Common "common";

module {
  public type PortfolioItem = {
    id : Nat;
    fileBlob : Storage.ExternalBlob;
    category : Common.ServiceType;
    caption : Text;
    description : Text;
    createdAt : Common.Timestamp;
  };
};
