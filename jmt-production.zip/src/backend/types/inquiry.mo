import Common "common";

module {
  public type Inquiry = {
    id : Nat;
    name : Text;
    email : Text;
    phone : Text;
    serviceType : Common.ServiceType;
    message : Text;
    createdAt : Common.Timestamp;
    isViewed : Bool;
  };

  public type InquiryInput = {
    name : Text;
    email : Text;
    phone : Text;
    serviceType : Common.ServiceType;
    message : Text;
  };
};
