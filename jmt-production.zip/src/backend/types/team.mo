import Storage "mo:caffeineai-object-storage/Storage";

module {
  public type TeamMember = {
    id : Nat;
    name : Text;
    role : Text;
    photoBlob : Storage.ExternalBlob;
    bio : Text;
    order : Nat;
  };
};
