import Storage "mo:caffeineai-object-storage/Storage";

module {
  public type BrandingConfig = {
    logo : ?Storage.ExternalBlob;
  };
};
