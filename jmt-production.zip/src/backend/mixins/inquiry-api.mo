import List "mo:core/List";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Types "../types/inquiry";
import InquiryLib "../lib/inquiry";

mixin (
  accessControlState : AccessControl.AccessControlState,
  inquiries : List.List<Types.Inquiry>,
  inquiryState : { var nextId : Nat },
) {
  /// Public: anyone can submit an inquiry
  public shared func submitInquiry(input : Types.InquiryInput) : async Types.Inquiry {
    InquiryLib.submitInquiry(inquiries, inquiryState, input);
  };

  /// Admin: list all inquiries
  public shared query ({ caller }) func listInquiries() : async [Types.Inquiry] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can list inquiries");
    };
    InquiryLib.listInquiries(inquiries);
  };

  /// Admin: mark inquiry as viewed
  public shared ({ caller }) func markInquiryViewed(id : Nat) : async Bool {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can mark inquiries as viewed");
    };
    InquiryLib.markViewed(inquiries, id);
  };

  /// Admin: delete an inquiry
  public shared ({ caller }) func deleteInquiry(id : Nat) : async Bool {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete inquiries");
    };
    InquiryLib.deleteInquiry(inquiries, id);
  };
};
