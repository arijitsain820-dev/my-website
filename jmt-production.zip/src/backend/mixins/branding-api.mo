import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/branding";
import BrandingLib "../lib/branding";

mixin (
  accessControlState : AccessControl.AccessControlState,
  brandingState : { var config : Types.BrandingConfig },
) {
  /// Public: get the current branding logo
  public query func getBrandingLogo() : async ?Storage.ExternalBlob {
    BrandingLib.getLogo(brandingState);
  };

  /// Admin: set the branding logo
  public shared ({ caller }) func setBrandingLogo(blob : Storage.ExternalBlob) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can set the branding logo");
    };
    BrandingLib.setLogo(brandingState, blob);
  };
};
