import List "mo:core/List";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/team";
import TeamLib "../lib/team";

mixin (
  accessControlState : AccessControl.AccessControlState,
  teamMembers : List.List<Types.TeamMember>,
  teamState : { var nextId : Nat },
) {
  /// Public: list all team members sorted by order
  public query func listTeamMembers() : async [Types.TeamMember] {
    TeamLib.listMembers(teamMembers);
  };

  /// Admin: add a new team member
  public shared ({ caller }) func addTeamMember(
    name : Text,
    role : Text,
    photoBlob : Storage.ExternalBlob,
    bio : Text,
    order : Nat,
  ) : async Types.TeamMember {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add team members");
    };
    TeamLib.addMember(teamMembers, teamState, name, role, photoBlob, bio, order);
  };

  /// Admin: update an existing team member
  public shared ({ caller }) func updateTeamMember(
    id : Nat,
    name : Text,
    role : Text,
    photoBlob : Storage.ExternalBlob,
    bio : Text,
    order : Nat,
  ) : async Bool {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can update team members");
    };
    TeamLib.updateMember(teamMembers, id, name, role, photoBlob, bio, order);
  };

  /// Admin: delete a team member by id
  public shared ({ caller }) func deleteTeamMember(id : Nat) : async Bool {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete team members");
    };
    TeamLib.deleteMember(teamMembers, id);
  };
};
