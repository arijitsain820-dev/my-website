import List "mo:core/List";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/portfolio";
import Common "../types/common";
import PortfolioLib "../lib/portfolio";

mixin (
  accessControlState : AccessControl.AccessControlState,
  portfolioItems : List.List<Types.PortfolioItem>,
  portfolioState : { var nextId : Nat },
) {
  /// Public: list portfolio items, optionally filtered by category
  public query func listPortfolioItems(category : ?Common.ServiceType) : async [Types.PortfolioItem] {
    PortfolioLib.listItems(portfolioItems, category);
  };

  /// Admin: add a new portfolio item
  public shared ({ caller }) func addPortfolioItem(
    fileBlob : Storage.ExternalBlob,
    category : Common.ServiceType,
    caption : Text,
    description : Text,
  ) : async Types.PortfolioItem {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can add portfolio items");
    };
    PortfolioLib.addItem(portfolioItems, portfolioState, fileBlob, category, caption, description);
  };

  /// Admin: delete a portfolio item by id
  public shared ({ caller }) func deletePortfolioItem(id : Nat) : async Bool {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete portfolio items");
    };
    PortfolioLib.deleteItem(portfolioItems, id);
  };
};
