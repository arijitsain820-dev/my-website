import List "mo:core/List";
import AccessControl "mo:caffeineai-authorization/access-control";
import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import MixinObjectStorage "mo:caffeineai-object-storage/Mixin";
import PortfolioTypes "types/portfolio";
import TeamTypes "types/team";
import InquiryTypes "types/inquiry";
import PortfolioMixin "mixins/portfolio-api";
import TeamMixin "mixins/team-api";
import InquiryMixin "mixins/inquiry-api";
import BrandingTypes "types/branding";
import BrandingMixin "mixins/branding-api";

actor {
  // Authorization
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  // Object storage infrastructure
  include MixinObjectStorage();

  // Portfolio state
  let portfolioItems = List.empty<PortfolioTypes.PortfolioItem>();
  let portfolioState = { var nextId : Nat = 0 };
  include PortfolioMixin(accessControlState, portfolioItems, portfolioState);

  // Team state
  let teamMembers = List.empty<TeamTypes.TeamMember>();
  let teamState = { var nextId : Nat = 0 };
  include TeamMixin(accessControlState, teamMembers, teamState);

  // Inquiry state
  let inquiries = List.empty<InquiryTypes.Inquiry>();
  let inquiryState = { var nextId : Nat = 0 };
  include InquiryMixin(accessControlState, inquiries, inquiryState);

  // Branding state
  let brandingState = { var config : BrandingTypes.BrandingConfig = { logo = null } };
  include BrandingMixin(accessControlState, brandingState);
};
