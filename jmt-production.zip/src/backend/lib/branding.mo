import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/branding";

module {
  public func getLogo(
    state : { var config : Types.BrandingConfig },
  ) : ?Storage.ExternalBlob {
    state.config.logo;
  };

  public func setLogo(
    state : { var config : Types.BrandingConfig },
    blob : Storage.ExternalBlob,
  ) {
    state.config := { logo = ?blob };
  };
};
