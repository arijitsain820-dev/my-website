import List "mo:core/List";
import Time "mo:core/Time";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/portfolio";
import Common "../types/common";

module {
  public func listItems(
    items : List.List<Types.PortfolioItem>,
    category : ?Common.ServiceType,
  ) : [Types.PortfolioItem] {
    switch (category) {
      case null { items.toArray() };
      case (?cat) {
        items.filter(func(item) { item.category == cat }).toArray();
      };
    };
  };

  public func addItem(
    items : List.List<Types.PortfolioItem>,
    state : { var nextId : Nat },
    fileBlob : Storage.ExternalBlob,
    category : Common.ServiceType,
    caption : Text,
    description : Text,
  ) : Types.PortfolioItem {
    let id = state.nextId;
    state.nextId += 1;
    let item : Types.PortfolioItem = {
      id;
      fileBlob;
      category;
      caption;
      description;
      createdAt = Time.now();
    };
    items.add(item);
    item;
  };

  public func deleteItem(
    items : List.List<Types.PortfolioItem>,
    id : Nat,
  ) : Bool {
    let sizeBefore = items.size();
    let filtered = items.filter(func(item) { item.id != id });
    let sizeAfter = filtered.size();
    if (sizeAfter < sizeBefore) {
      items.clear();
      items.append(filtered);
      true;
    } else {
      false;
    };
  };
};
