import List "mo:core/List";
import Time "mo:core/Time";
import Types "../types/inquiry";

module {
  public func submitInquiry(
    inquiries : List.List<Types.Inquiry>,
    state : { var nextId : Nat },
    input : Types.InquiryInput,
  ) : Types.Inquiry {
    let id = state.nextId;
    state.nextId += 1;
    let inquiry : Types.Inquiry = {
      id;
      name = input.name;
      email = input.email;
      phone = input.phone;
      serviceType = input.serviceType;
      message = input.message;
      createdAt = Time.now();
      isViewed = false;
    };
    inquiries.add(inquiry);
    inquiry;
  };

  public func listInquiries(
    inquiries : List.List<Types.Inquiry>,
  ) : [Types.Inquiry] {
    inquiries.toArray();
  };

  public func markViewed(
    inquiries : List.List<Types.Inquiry>,
    id : Nat,
  ) : Bool {
    var found = false;
    inquiries.mapInPlace(
      func(inq) {
        if (inq.id == id) {
          found := true;
          { inq with isViewed = true };
        } else { inq };
      }
    );
    found;
  };

  public func deleteInquiry(
    inquiries : List.List<Types.Inquiry>,
    id : Nat,
  ) : Bool {
    let sizeBefore = inquiries.size();
    let filtered = inquiries.filter(func(inq) { inq.id != id });
    let sizeAfter = filtered.size();
    if (sizeAfter < sizeBefore) {
      inquiries.clear();
      inquiries.append(filtered);
      true;
    } else {
      false;
    };
  };
};
