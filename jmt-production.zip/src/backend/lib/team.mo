import List "mo:core/List";
import Array "mo:core/Array";
import Nat "mo:core/Nat";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/team";

module {
  public func listMembers(
    members : List.List<Types.TeamMember>,
  ) : [Types.TeamMember] {
    let arr = members.toArray();
    arr.sort(func(a, b) { Nat.compare(a.order, b.order) });
  };

  public func addMember(
    members : List.List<Types.TeamMember>,
    state : { var nextId : Nat },
    name : Text,
    role : Text,
    photoBlob : Storage.ExternalBlob,
    bio : Text,
    order : Nat,
  ) : Types.TeamMember {
    let id = state.nextId;
    state.nextId += 1;
    let member : Types.TeamMember = {
      id;
      name;
      role;
      photoBlob;
      bio;
      order;
    };
    members.add(member);
    member;
  };

  public func updateMember(
    members : List.List<Types.TeamMember>,
    id : Nat,
    name : Text,
    role : Text,
    photoBlob : Storage.ExternalBlob,
    bio : Text,
    order : Nat,
  ) : Bool {
    var found = false;
    members.mapInPlace(
      func(m) {
        if (m.id == id) {
          found := true;
          { id; name; role; photoBlob; bio; order };
        } else { m };
      }
    );
    found;
  };

  public func deleteMember(
    members : List.List<Types.TeamMember>,
    id : Nat,
  ) : Bool {
    let sizeBefore = members.size();
    let filtered = members.filter(func(m) { m.id != id });
    let sizeAfter = filtered.size();
    if (sizeAfter < sizeBefore) {
      members.clear();
      members.append(filtered);
      true;
    } else {
      false;
    };
  };
};
