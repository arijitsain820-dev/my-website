import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export class ExternalBlob {
    getBytes(): Promise<Uint8Array<ArrayBuffer>>;
    getDirectURL(): string;
    static fromURL(url: string): ExternalBlob;
    static fromBytes(blob: Uint8Array<ArrayBuffer>): ExternalBlob;
    withUploadProgress(onProgress: (percentage: number) => void): ExternalBlob;
}
export type Timestamp = bigint;
export interface PortfolioItem {
    id: bigint;
    createdAt: Timestamp;
    fileBlob: ExternalBlob;
    description: string;
    caption: string;
    category: ServiceType;
}
export interface TeamMember {
    id: bigint;
    bio: string;
    photoBlob: ExternalBlob;
    order: bigint;
    name: string;
    role: string;
}
export interface InquiryInput {
    serviceType: ServiceType;
    name: string;
    email: string;
    message: string;
    phone: string;
}
export interface Inquiry {
    id: bigint;
    serviceType: ServiceType;
    isViewed: boolean;
    name: string;
    createdAt: Timestamp;
    email: string;
    message: string;
    phone: string;
}
export enum ServiceType {
    VideoEditing = "VideoEditing",
    Wedding = "Wedding",
    Birthday = "Birthday",
    Fashion = "Fashion",
    SocialMedia = "SocialMedia",
    Concert = "Concert"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addPortfolioItem(fileBlob: ExternalBlob, category: ServiceType, caption: string, description: string): Promise<PortfolioItem>;
    addTeamMember(name: string, role: string, photoBlob: ExternalBlob, bio: string, order: bigint): Promise<TeamMember>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    deleteInquiry(id: bigint): Promise<boolean>;
    deletePortfolioItem(id: bigint): Promise<boolean>;
    deleteTeamMember(id: bigint): Promise<boolean>;
    getBrandingLogo(): Promise<ExternalBlob | null>;
    getCallerUserRole(): Promise<UserRole>;
    isCallerAdmin(): Promise<boolean>;
    listInquiries(): Promise<Array<Inquiry>>;
    listPortfolioItems(category: ServiceType | null): Promise<Array<PortfolioItem>>;
    listTeamMembers(): Promise<Array<TeamMember>>;
    markInquiryViewed(id: bigint): Promise<boolean>;
    setBrandingLogo(blob: ExternalBlob): Promise<void>;
    submitInquiry(input: InquiryInput): Promise<Inquiry>;
    updateTeamMember(id: bigint, name: string, role: string, photoBlob: ExternalBlob, bio: string, order: bigint): Promise<boolean>;
}
