import { Layout } from "@/components/Layout";
import { Skeleton } from "@/components/ui/skeleton";
import { useTeam } from "@/hooks/useTeam";
import type { TeamMember } from "@/types";
import { Award, Camera, Film, Star, Users, Zap } from "lucide-react";
import { motion } from "motion/react";

const WHY_TEAM_HIGHLIGHTS = [
  {
    icon: Camera,
    title: "Expert Cinematographers",
    description:
      "Our camera operators bring years of professional experience shooting weddings, fashion campaigns, and live events with cinematic precision.",
  },
  {
    icon: Film,
    title: "Master Post-Production",
    description:
      "Our editors craft narratives from raw footage — color grading, motion graphics, and sound design that elevate every frame.",
  },
  {
    icon: Zap,
    title: "Fast Turnaround",
    description:
      "We deliver polished content on time, every time. Tight deadlines are a challenge we embrace, not avoid.",
  },
  {
    icon: Award,
    title: "Premium Quality",
    description:
      "From gear selection to final export, every decision is made with a single goal: producing work that impresses audiences and clients alike.",
  },
  {
    icon: Users,
    title: "Collaborative Spirit",
    description:
      "We work closely with you at every stage — ideation, shoot, and delivery — so the final product reflects your vision.",
  },
  {
    icon: Star,
    title: "Full-Spectrum Services",
    description:
      "Wedding, fashion, concert, birthday, social media content — our team is trained across every genre of visual production.",
  },
];

const ROLE_COLORS: Record<string, string> = {
  Cinematographer: "bg-primary/20 text-primary border-primary/30",
  "Lead Cinematographer": "bg-primary/30 text-primary border-primary/40",
  Editor: "bg-accent/20 text-accent border-accent/30",
  "Lead Editor": "bg-accent/30 text-accent border-accent/40",
  "Video Editor": "bg-accent/20 text-accent border-accent/30",
  Photographer: "bg-primary/20 text-primary border-primary/30",
  "Creative Director": "bg-primary/40 text-primary border-primary/50",
};

function getRoleBadgeClass(role: string): string {
  return (
    ROLE_COLORS[role] ?? "bg-secondary text-secondary-foreground border-border"
  );
}

function MemberCard({
  member,
  index,
}: {
  member: TeamMember;
  index: number;
}) {
  const photoUrl = member.photoBlob ? member.photoBlob.getDirectURL() : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.55, delay: index * 0.1, ease: "easeOut" }}
      className="group flex flex-col items-center text-center"
      data-ocid={`team.member.card.${index + 1}`}
    >
      <div className="relative mb-5">
        <div
          className="w-40 h-40 rounded-full overflow-hidden border-2 border-primary/50
            ring-4 ring-primary/10 group-hover:ring-primary/30
            transition-all duration-500 shadow-[0_0_30px_rgba(0,0,0,0.6)]"
        >
          {photoUrl ? (
            <img
              src={photoUrl}
              alt={member.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full bg-secondary flex items-center justify-center">
              <Users className="w-14 h-14 text-muted-foreground/40" />
            </div>
          )}
        </div>
        <div
          className="absolute inset-0 rounded-full bg-primary/0 group-hover:bg-primary/5
            transition-all duration-500 blur-xl"
        />
      </div>

      <h3
        className="font-display text-lg font-semibold text-foreground
          group-hover:text-primary transition-colors duration-300 mb-2 tracking-wide"
        data-ocid={`team.member.name.${index + 1}`}
      >
        {member.name}
      </h3>

      <span
        className={`inline-block px-3 py-1 rounded-full text-xs font-semibold
          border tracking-wider uppercase mb-3
          ${getRoleBadgeClass(member.role)}`}
        data-ocid={`team.member.role.${index + 1}`}
      >
        {member.role}
      </span>

      {member.bio && (
        <p className="text-sm text-muted-foreground leading-relaxed max-w-[220px] line-clamp-3">
          {member.bio}
        </p>
      )}
    </motion.div>
  );
}

function SkeletonCard({ skKey }: { skKey: string }) {
  return (
    <div
      className="flex flex-col items-center gap-3"
      data-ocid={`team.member.loading_state.${skKey}`}
    >
      <Skeleton className="w-40 h-40 rounded-full" />
      <Skeleton className="h-5 w-32" />
      <Skeleton className="h-4 w-20 rounded-full" />
      <Skeleton className="h-3 w-48" />
      <Skeleton className="h-3 w-40" />
    </div>
  );
}

export default function TeamPage() {
  const { data: members, isLoading } = useTeam();

  return (
    <Layout>
      {/* Page Header */}
      <section
        className="relative pt-24 pb-16 overflow-hidden"
        data-ocid="team.header.section"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-card/80 via-background to-background pointer-events-none" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-primary/5 blur-[100px] rounded-full pointer-events-none" />

        <div className="relative container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <p className="text-primary text-sm font-semibold tracking-[0.25em] uppercase mb-4">
              Behind The Lens
            </p>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4 leading-tight">
              Meet Our Team
            </h1>
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="h-px w-16 bg-gradient-to-r from-transparent to-primary" />
              <div className="h-1 w-10 bg-primary rounded-full" />
              <div className="h-px w-16 bg-gradient-to-l from-transparent to-primary" />
            </div>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto leading-relaxed">
              A tight-knit crew of cinematographers and editors who live and
              breathe visual storytelling — built to bring your creative vision
              to life.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Team Grid */}
      <section className="py-16 bg-background" data-ocid="team.members.section">
        <div className="container mx-auto px-4">
          {isLoading ? (
            <div
              className="grid grid-cols-2 md:grid-cols-4 gap-12"
              data-ocid="team.loading_state"
            >
              {["a", "b", "c", "d"].map((k) => (
                <SkeletonCard key={`skeleton-member-${k}`} skKey={k} />
              ))}
            </div>
          ) : !members || members.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
              className="flex flex-col items-center justify-center py-24 gap-5"
              data-ocid="team.empty_state"
            >
              <div className="w-20 h-20 rounded-full bg-card border border-border flex items-center justify-center">
                <Users className="w-9 h-9 text-muted-foreground/50" />
              </div>
              <div className="text-center">
                <h3 className="font-display text-xl font-semibold text-foreground mb-2">
                  Team profiles coming soon
                </h3>
                <p className="text-muted-foreground text-sm max-w-xs">
                  Our admin is uploading member profiles. Check back shortly.
                </p>
              </div>
            </motion.div>
          ) : (
            <div
              className="grid grid-cols-2 md:grid-cols-4 gap-x-8 gap-y-14"
              data-ocid="team.members.list"
            >
              {members.map((member, index) => (
                <MemberCard
                  key={`team-member-${String(member.id)}`}
                  member={member}
                  index={index}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Why Our Team */}
      <section
        className="py-20 bg-card/40 border-t border-border"
        data-ocid="team.why.section"
      >
        <div className="flex items-center justify-center gap-3 mb-12">
          <div className="h-px w-24 bg-gradient-to-r from-transparent to-primary" />
          <div className="h-1.5 w-12 bg-primary rounded-full" />
          <div className="h-px w-24 bg-gradient-to-l from-transparent to-primary" />
        </div>

        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-14"
          >
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-3">
              Why Our Team?
            </h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Specialized talent, unified by a passion for extraordinary
              visuals.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {WHY_TEAM_HIGHLIGHTS.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                className="group flex gap-4 p-5 rounded-xl bg-card border border-border
                  hover:border-primary/40 hover:bg-card/80 transition-all duration-300"
                data-ocid={`team.why.item.${index + 1}`}
              >
                <div
                  className="flex-shrink-0 w-11 h-11 rounded-lg bg-primary/10
                    flex items-center justify-center
                    group-hover:bg-primary/20 transition-colors duration-300"
                >
                  <item.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-1 group-hover:text-primary transition-colors duration-300">
                    {item.title}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
