import { ExternalBlob, type ServiceType } from "@/backend";
import type { TeamMember } from "@/backend";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useLogoSrc, useSetBrandingLogo } from "@/hooks/useBranding";
import {
  useDeleteInquiry,
  useInquiries,
  useMarkInquiryViewed,
} from "@/hooks/useInquiries";
import {
  useAddPortfolioItem,
  useDeletePortfolioItem,
  usePortfolio,
} from "@/hooks/usePortfolio";
import {
  useAddTeamMember,
  useDeleteTeamMember,
  useTeam,
  useUpdateTeamMember,
} from "@/hooks/useTeam";
import { SERVICE_LABELS, formatTimestamp, getImageUrl } from "@/types";
import {
  Eye,
  ImageIcon,
  Loader2,
  Pencil,
  Plus,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { useRef, useState } from "react";

const SERVICE_OPTIONS = Object.entries(SERVICE_LABELS).map(
  ([value, label]) => ({ value, label }),
);

// --- Inquiries Tab
function InquiriesTab() {
  const { data: inquiries = [], isLoading } = useInquiries();
  const markViewed = useMarkInquiryViewed();
  const deleteInquiry = useDeleteInquiry();

  if (isLoading) return <LoadingSpinner />;

  if (inquiries.length === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center py-24 gap-4"
        data-ocid="inquiries.empty_state"
      >
        <p className="text-muted-foreground text-lg">No inquiries yet.</p>
      </div>
    );
  }

  return (
    <div
      className="overflow-x-auto rounded-lg border border-border"
      data-ocid="inquiries.table"
    >
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border bg-card">
            <th className="text-left px-4 py-3 text-muted-foreground font-medium">
              Date
            </th>
            <th className="text-left px-4 py-3 text-muted-foreground font-medium">
              Name
            </th>
            <th className="text-left px-4 py-3 text-muted-foreground font-medium">
              Phone
            </th>
            <th className="text-left px-4 py-3 text-muted-foreground font-medium">
              Email
            </th>
            <th className="text-left px-4 py-3 text-muted-foreground font-medium">
              Service
            </th>
            <th className="text-left px-4 py-3 text-muted-foreground font-medium">
              Message
            </th>
            <th className="text-left px-4 py-3 text-muted-foreground font-medium">
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          {inquiries.map((inq, i) => (
            <tr
              key={String(inq.id)}
              data-ocid={`inquiries.item.${i + 1}`}
              className={`border-b border-border last:border-0 transition-colors hover:bg-muted/20 ${
                inq.isViewed ? "opacity-70" : ""
              }`}
            >
              <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">
                {formatTimestamp(inq.createdAt)}
              </td>
              <td
                className={`px-4 py-3 whitespace-nowrap ${!inq.isViewed ? "font-bold text-foreground" : "text-muted-foreground"}`}
              >
                {inq.name}
                {!inq.isViewed && (
                  <span className="ml-2 inline-block w-2 h-2 rounded-full bg-primary" />
                )}
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">
                {inq.phone}
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">
                {inq.email}
              </td>
              <td className="px-4 py-3">
                <Badge variant="secondary" className="text-xs">
                  {SERVICE_LABELS[inq.serviceType as string] ?? inq.serviceType}
                </Badge>
              </td>
              <td
                className="px-4 py-3 max-w-[240px] truncate text-muted-foreground"
                title={inq.message}
              >
                {inq.message}
              </td>
              <td className="px-4 py-3">
                <div className="flex gap-2">
                  {!inq.isViewed && (
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      title="Mark as viewed"
                      data-ocid={`inquiries.mark_viewed.${i + 1}`}
                      onClick={() => markViewed.mutate(inq.id)}
                      disabled={markViewed.isPending}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                  )}
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        data-ocid={`inquiries.delete_button.${i + 1}`}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent data-ocid="inquiries.dialog">
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Inquiry</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently delete the inquiry from{" "}
                          {inq.name}.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel data-ocid="inquiries.cancel_button">
                          Cancel
                        </AlertDialogCancel>
                        <AlertDialogAction
                          data-ocid="inquiries.confirm_button"
                          onClick={() => deleteInquiry.mutate(inq.id)}
                          className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// --- Portfolio Tab
function PortfolioTab() {
  const { data: items = [], isLoading } = usePortfolio();
  const addItem = useAddPortfolioItem();
  const deleteItem = useDeletePortfolioItem();

  const [caption, setCaption] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);

  const resetForm = () => {
    setCaption("");
    setDescription("");
    setCategory("");
    setFile(null);
    setProgress(0);
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleUpload = async () => {
    if (!file || !category) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    const blob = ExternalBlob.fromBytes(bytes).withUploadProgress((p) =>
      setProgress(p),
    );
    await addItem.mutateAsync({
      fileBlob: blob,
      category: category as ServiceType,
      caption,
      description,
    });
    resetForm();
  };

  return (
    <div className="space-y-8">
      <Card className="border-border bg-card" data-ocid="portfolio.upload_form">
        <CardHeader>
          <CardTitle className="text-foreground font-display text-lg flex items-center gap-2">
            <Plus className="w-4 h-4 text-primary" /> Add Portfolio Item
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="caption">Caption</Label>
              <Input
                id="caption"
                placeholder="e.g. Rooftop Wedding Shoot"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                data-ocid="portfolio.caption_input"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="p-category">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger
                  id="p-category"
                  data-ocid="portfolio.category_select"
                >
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {SERVICE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Brief description of the work…"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              data-ocid="portfolio.description_textarea"
              rows={2}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="p-file">Photo / Video</Label>
            <button
              type="button"
              className="w-full border border-dashed border-border rounded-lg p-4 flex flex-col items-center gap-2 cursor-pointer hover:border-primary transition-colors"
              onClick={() => fileRef.current?.click()}
              data-ocid="portfolio.dropzone"
            >
              <Upload className="w-6 h-6 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                {file ? file.name : "Click to select image or video"}
              </p>
              <input
                ref={fileRef}
                id="p-file"
                type="file"
                accept="image/*,video/*"
                className="hidden"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                data-ocid="portfolio.upload_button"
              />
            </button>
          </div>
          {addItem.isPending && progress > 0 && (
            <div className="space-y-1" data-ocid="portfolio.loading_state">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Uploading…</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
          {addItem.isError && (
            <p
              className="text-sm text-destructive"
              data-ocid="portfolio.error_state"
            >
              Upload failed. Please try again.
            </p>
          )}
          <Button
            type="button"
            className="cta-button w-full sm:w-auto px-6 py-2 rounded"
            onClick={handleUpload}
            disabled={!file || !category || addItem.isPending}
            data-ocid="portfolio.submit_button"
          >
            {addItem.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Uploading…
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" /> Upload Item
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {isLoading ? (
        <LoadingSpinner />
      ) : items.length === 0 ? (
        <div
          className="text-center py-16 text-muted-foreground"
          data-ocid="portfolio.empty_state"
        >
          No portfolio items yet.
        </div>
      ) : (
        <div
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4"
          data-ocid="portfolio.list"
        >
          {items.map((item, i) => (
            <div
              key={String(item.id)}
              className="relative group rounded-lg overflow-hidden border border-border bg-card"
              data-ocid={`portfolio.item.${i + 1}`}
            >
              <img
                src={getImageUrl(item.fileBlob)}
                alt={item.caption}
                className="w-full aspect-square object-cover"
              />
              <div className="p-2">
                <p className="text-xs font-medium text-foreground truncate">
                  {item.caption}
                </p>
                <p className="text-xs text-muted-foreground">
                  {SERVICE_LABELS[item.category as string] ?? item.category}
                </p>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <button
                    type="button"
                    data-ocid={`portfolio.delete_button.${i + 1}`}
                    className="absolute top-2 right-2 bg-background/80 text-destructive rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Delete"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </AlertDialogTrigger>
                <AlertDialogContent data-ocid="portfolio.dialog">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Portfolio Item</AlertDialogTitle>
                    <AlertDialogDescription>
                      Remove "{item.caption}" from the portfolio? This cannot be
                      undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel data-ocid="portfolio.cancel_button">
                      Cancel
                    </AlertDialogCancel>
                    <AlertDialogAction
                      data-ocid="portfolio.confirm_button"
                      onClick={() => deleteItem.mutate(item.id)}
                      className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                    >
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// --- Team Tab
interface MemberFormState {
  name: string;
  role: string;
  bio: string;
  order: string;
  file: File | null;
  progress: number;
}

const EMPTY_FORM: MemberFormState = {
  name: "",
  role: "",
  bio: "",
  order: "",
  file: null,
  progress: 0,
};

function TeamTab() {
  const { data: members = [], isLoading } = useTeam();
  const addMember = useAddTeamMember();
  const updateMember = useUpdateTeamMember();
  const deleteMember = useDeleteTeamMember();

  const [form, setForm] = useState<MemberFormState>(EMPTY_FORM);
  const [editingId, setEditingId] = useState<bigint | null>(null);
  const [editFile, setEditFile] = useState<File | null>(null);
  const [editProgress, setEditProgress] = useState(0);
  const [editForm, setEditForm] = useState<
    Omit<MemberFormState, "file" | "progress">
  >({ name: "", role: "", bio: "", order: "" });
  const fileRef = useRef<HTMLInputElement>(null);
  const editFileRef = useRef<HTMLInputElement>(null);

  const resetForm = () => {
    setForm(EMPTY_FORM);
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleAdd = async () => {
    if (!form.name || !form.role || !form.file) return;
    const bytes = new Uint8Array(await form.file.arrayBuffer());
    const blob = ExternalBlob.fromBytes(bytes).withUploadProgress((p) =>
      setForm((prev) => ({ ...prev, progress: p })),
    );
    await addMember.mutateAsync({
      name: form.name,
      role: form.role,
      photoBlob: blob,
      bio: form.bio,
      order: BigInt(form.order || 0),
    });
    resetForm();
  };

  const startEdit = (m: TeamMember) => {
    setEditingId(m.id);
    setEditForm({
      name: m.name,
      role: m.role,
      bio: m.bio,
      order: String(m.order),
    });
    setEditFile(null);
    setEditProgress(0);
  };

  const handleUpdate = async (m: TeamMember) => {
    let blob: ExternalBlob;
    if (editFile) {
      const bytes = new Uint8Array(await editFile.arrayBuffer());
      blob = ExternalBlob.fromBytes(bytes).withUploadProgress((p) =>
        setEditProgress(p),
      );
    } else {
      blob = m.photoBlob;
    }
    await updateMember.mutateAsync({
      id: m.id,
      name: editForm.name,
      role: editForm.role,
      photoBlob: blob,
      bio: editForm.bio,
      order: BigInt(editForm.order || 0),
    });
    setEditingId(null);
    setEditFile(null);
    if (editFileRef.current) editFileRef.current.value = "";
  };

  return (
    <div className="space-y-8">
      <Card className="border-border bg-card" data-ocid="team.add_form">
        <CardHeader>
          <CardTitle className="text-foreground font-display text-lg flex items-center gap-2">
            <Plus className="w-4 h-4 text-primary" /> Add Team Member
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="t-name">Name</Label>
              <Input
                id="t-name"
                placeholder="Rahul Sharma"
                value={form.name}
                onChange={(e) =>
                  setForm((p) => ({ ...p, name: e.target.value }))
                }
                data-ocid="team.name_input"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="t-role">Role</Label>
              <Input
                id="t-role"
                placeholder="Lead Photographer"
                value={form.role}
                onChange={(e) =>
                  setForm((p) => ({ ...p, role: e.target.value }))
                }
                data-ocid="team.role_input"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="t-bio">Bio</Label>
              <Textarea
                id="t-bio"
                placeholder="Short bio…"
                value={form.bio}
                rows={2}
                onChange={(e) =>
                  setForm((p) => ({ ...p, bio: e.target.value }))
                }
                data-ocid="team.bio_textarea"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="t-order">Display Order</Label>
              <Input
                id="t-order"
                type="number"
                placeholder="1"
                value={form.order}
                onChange={(e) =>
                  setForm((p) => ({ ...p, order: e.target.value }))
                }
                data-ocid="team.order_input"
              />
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="t-photo">Photo</Label>
            <button
              type="button"
              className="w-full border border-dashed border-border rounded-lg p-4 flex flex-col items-center gap-2 cursor-pointer hover:border-primary transition-colors"
              onClick={() => fileRef.current?.click()}
              data-ocid="team.dropzone"
            >
              <Upload className="w-6 h-6 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                {form.file ? form.file.name : "Click to select photo"}
              </p>
              <input
                ref={fileRef}
                id="t-photo"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) =>
                  setForm((p) => ({ ...p, file: e.target.files?.[0] ?? null }))
                }
                data-ocid="team.upload_button"
              />
            </button>
          </div>
          {addMember.isPending && form.progress > 0 && (
            <div className="space-y-1" data-ocid="team.loading_state">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Uploading…</span>
                <span>{Math.round(form.progress)}%</span>
              </div>
              <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all"
                  style={{ width: `${form.progress}%` }}
                />
              </div>
            </div>
          )}
          {addMember.isError && (
            <p
              className="text-sm text-destructive"
              data-ocid="team.error_state"
            >
              Upload failed. Please try again.
            </p>
          )}
          <Button
            type="button"
            className="cta-button px-6 py-2 rounded w-full sm:w-auto"
            onClick={handleAdd}
            disabled={
              !form.name || !form.role || !form.file || addMember.isPending
            }
            data-ocid="team.submit_button"
          >
            {addMember.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving…
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" /> Add Member
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {isLoading ? (
        <LoadingSpinner />
      ) : members.length === 0 ? (
        <div
          className="text-center py-16 text-muted-foreground"
          data-ocid="team.empty_state"
        >
          No team members yet.
        </div>
      ) : (
        <div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          data-ocid="team.list"
        >
          {members
            .slice()
            .sort((a, b) => Number(a.order) - Number(b.order))
            .map((member, i) => (
              <Card
                key={String(member.id)}
                className="border-border bg-card"
                data-ocid={`team.item.${i + 1}`}
              >
                {editingId === member.id ? (
                  <CardContent className="pt-4 space-y-3">
                    <Input
                      placeholder="Name"
                      value={editForm.name}
                      onChange={(e) =>
                        setEditForm((p) => ({ ...p, name: e.target.value }))
                      }
                      data-ocid={`team.edit_name.${i + 1}`}
                    />
                    <Input
                      placeholder="Role"
                      value={editForm.role}
                      onChange={(e) =>
                        setEditForm((p) => ({ ...p, role: e.target.value }))
                      }
                      data-ocid={`team.edit_role.${i + 1}`}
                    />
                    <Textarea
                      placeholder="Bio"
                      value={editForm.bio}
                      rows={2}
                      onChange={(e) =>
                        setEditForm((p) => ({ ...p, bio: e.target.value }))
                      }
                      data-ocid={`team.edit_bio.${i + 1}`}
                    />
                    <Input
                      type="number"
                      placeholder="Order"
                      value={editForm.order}
                      onChange={(e) =>
                        setEditForm((p) => ({ ...p, order: e.target.value }))
                      }
                      data-ocid={`team.edit_order.${i + 1}`}
                    />
                    <button
                      type="button"
                      className="w-full border border-dashed border-border rounded p-2 flex items-center gap-2 cursor-pointer hover:border-primary transition-colors text-sm"
                      onClick={() => editFileRef.current?.click()}
                    >
                      <Upload className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">
                        {editFile ? editFile.name : "Replace photo (optional)"}
                      </span>
                      <input
                        ref={editFileRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) =>
                          setEditFile(e.target.files?.[0] ?? null)
                        }
                      />
                    </button>
                    {updateMember.isPending && editProgress > 0 && (
                      <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-primary transition-all"
                          style={{ width: `${editProgress}%` }}
                        />
                      </div>
                    )}
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        size="sm"
                        className="cta-button flex-1 rounded"
                        onClick={() => handleUpdate(member)}
                        disabled={updateMember.isPending}
                        data-ocid={`team.save_button.${i + 1}`}
                      >
                        {updateMember.isPending ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          "Save"
                        )}
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => setEditingId(null)}
                        data-ocid={`team.cancel_button.${i + 1}`}
                      >
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                ) : (
                  <CardContent className="pt-4">
                    <div className="flex gap-4">
                      <img
                        src={getImageUrl(member.photoBlob)}
                        alt={member.name}
                        className="w-16 h-16 rounded-full object-cover border-2 border-primary/30 flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground truncate">
                          {member.name}
                        </p>
                        <p className="text-sm text-primary truncate">
                          {member.role}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                          {member.bio}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="flex-1"
                        onClick={() => startEdit(member)}
                        data-ocid={`team.edit_button.${i + 1}`}
                      >
                        <Pencil className="w-3.5 h-3.5 mr-1" /> Edit
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            className="text-destructive hover:text-destructive"
                            data-ocid={`team.delete_button.${i + 1}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent data-ocid="team.dialog">
                          <AlertDialogHeader>
                            <AlertDialogTitle>
                              Remove Team Member
                            </AlertDialogTitle>
                            <AlertDialogDescription>
                              Remove {member.name} from the team? This cannot be
                              undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel data-ocid="team.cancel_button">
                              Cancel
                            </AlertDialogCancel>
                            <AlertDialogAction
                              data-ocid="team.confirm_button"
                              onClick={() => deleteMember.mutate(member.id)}
                              className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                            >
                              Remove
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
        </div>
      )}
    </div>
  );
}

// --- Branding Tab
function BrandingTab() {
  const logoSrc = useLogoSrc();
  const setLogo = useSetBrandingLogo();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (f: File | null) => {
    setFile(f);
    if (f) {
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target?.result as string);
      reader.readAsDataURL(f);
    } else {
      setPreview(null);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setProgress(0);
    await setLogo.mutateAsync({
      file,
      onProgress: setProgress,
    });
    setFile(null);
    setPreview(null);
    setProgress(0);
    if (fileRef.current) fileRef.current.value = "";
  };

  const FALLBACK =
    "/assets/whatsapp_image_2026-05-18_at_1.51.31_am-removebg-preview_1-019e3b79-4fad-74da-ad18-0113e096e6a9.png";

  return (
    <div className="space-y-8 max-w-lg">
      <Card
        className="border-border bg-card"
        data-ocid="branding.current_logo_card"
      >
        <CardHeader>
          <CardTitle className="text-foreground font-display text-lg flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-primary" /> Current Logo
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-start gap-4">
          <div className="rounded-lg border border-border bg-muted/30 p-4 flex items-center justify-center w-full min-h-[120px]">
            <img
              src={logoSrc !== FALLBACK ? logoSrc : FALLBACK}
              alt="Current Logo"
              className="max-h-24 max-w-full object-contain"
              data-ocid="branding.current_logo"
            />
          </div>
          {logoSrc === FALLBACK && (
            <p
              className="text-sm text-muted-foreground"
              data-ocid="branding.no_logo_state"
            >
              No custom logo uploaded yet. Using default logo.
            </p>
          )}
        </CardContent>
      </Card>

      <Card className="border-border bg-card" data-ocid="branding.upload_form">
        <CardHeader>
          <CardTitle className="text-foreground font-display text-lg flex items-center gap-2">
            <Upload className="w-4 h-4 text-primary" /> Upload New Logo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1">
            <Label htmlFor="logo-file">Logo Image</Label>
            <button
              type="button"
              className="w-full border border-dashed border-border rounded-lg p-6 flex flex-col items-center gap-3 cursor-pointer hover:border-primary transition-colors"
              onClick={() => fileRef.current?.click()}
              data-ocid="branding.dropzone"
            >
              {preview ? (
                <img
                  src={preview}
                  alt="Preview"
                  className="max-h-20 max-w-full object-contain"
                />
              ) : (
                <>
                  <Upload className="w-8 h-8 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground text-center">
                    Click to select logo image
                    <br />
                    <span className="text-xs">
                      (PNG with transparent background recommended)
                    </span>
                  </p>
                </>
              )}
              {file && (
                <span className="text-xs text-muted-foreground mt-1">
                  {file.name}
                </span>
              )}
              <input
                ref={fileRef}
                id="logo-file"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleFileChange(e.target.files?.[0] ?? null)}
                data-ocid="branding.upload_button"
              />
            </button>
          </div>

          {setLogo.isPending && progress > 0 && (
            <div className="space-y-1" data-ocid="branding.loading_state">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Uploading…</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {setLogo.isError && (
            <p
              className="text-sm text-destructive"
              data-ocid="branding.error_state"
            >
              Upload failed. Please try again.
            </p>
          )}

          {setLogo.isSuccess && (
            <p
              className="text-sm text-green-600"
              data-ocid="branding.success_state"
            >
              Logo updated successfully!
            </p>
          )}

          <Button
            type="button"
            className="cta-button w-full sm:w-auto px-6 py-2 rounded"
            onClick={handleUpload}
            disabled={!file || setLogo.isPending}
            data-ocid="branding.submit_button"
          >
            {setLogo.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Uploading…
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" /> Save Logo
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// --- Shared
function LoadingSpinner() {
  return (
    <div className="flex justify-center py-20">
      <Loader2 className="w-8 h-8 text-primary animate-spin" />
    </div>
  );
}

// --- Admin Page
export function Admin() {
  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background">
        <header
          className="bg-card border-b border-border px-6 py-4 flex items-center gap-3"
          data-ocid="admin.header"
        >
          <img
            src="/assets/whatsapp_image_2026-05-18_at_1.51.31_am-removebg-preview_1-019e3b79-4fad-74da-ad18-0113e096e6a9.png"
            alt="JMT Production"
            className="h-10 w-auto"
          />
          <p className="text-xs text-primary font-semibold uppercase tracking-widest">
            Admin Panel
          </p>
        </header>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Tabs defaultValue="inquiries" data-ocid="admin.tabs">
            <TabsList className="mb-8 bg-card border border-border">
              <TabsTrigger
                value="inquiries"
                data-ocid="admin.inquiries_tab"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-medium"
              >
                Inquiries
              </TabsTrigger>
              <TabsTrigger
                value="portfolio"
                data-ocid="admin.portfolio_tab"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-medium"
              >
                Portfolio
              </TabsTrigger>
              <TabsTrigger
                value="team"
                data-ocid="admin.team_tab"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-medium"
              >
                Team Members
              </TabsTrigger>
              <TabsTrigger
                value="branding"
                data-ocid="admin.branding_tab"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-medium"
              >
                Branding
              </TabsTrigger>
            </TabsList>

            <TabsContent value="inquiries" data-ocid="admin.inquiries_panel">
              <InquiriesTab />
            </TabsContent>
            <TabsContent value="portfolio" data-ocid="admin.portfolio_panel">
              <PortfolioTab />
            </TabsContent>
            <TabsContent value="team" data-ocid="admin.team_panel">
              <TeamTab />
            </TabsContent>
            <TabsContent value="branding" data-ocid="admin.branding_panel">
              <BrandingTab />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ProtectedRoute>
  );
}

export default Admin;
