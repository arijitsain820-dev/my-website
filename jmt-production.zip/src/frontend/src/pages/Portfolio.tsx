import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { usePortfolio } from "@/hooks/usePortfolio";
import { SERVICE_LABELS } from "@/types";
import type { PortfolioItem } from "@/types";
import { ServiceType } from "@/types";
import { useNavigate, useSearch } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Play, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

// ── Types ────────────────────────────────────────────────────────────────────

type FilterKey = "all" | ServiceType;

interface FilterTab {
  key: FilterKey;
  label: string;
}

const FILTER_TABS: FilterTab[] = [
  { key: "all", label: "All" },
  { key: ServiceType.Wedding, label: SERVICE_LABELS[ServiceType.Wedding] },
  { key: ServiceType.Fashion, label: SERVICE_LABELS[ServiceType.Fashion] },
  { key: ServiceType.Concert, label: SERVICE_LABELS[ServiceType.Concert] },
  { key: ServiceType.Birthday, label: SERVICE_LABELS[ServiceType.Birthday] },
  {
    key: ServiceType.VideoEditing,
    label: SERVICE_LABELS[ServiceType.VideoEditing],
  },
  {
    key: ServiceType.SocialMedia,
    label: SERVICE_LABELS[ServiceType.SocialMedia],
  },
];

function isVideo(item: PortfolioItem): boolean {
  try {
    const url = item.fileBlob.getDirectURL();
    return /\.(mp4|webm|mov|avi|mkv)$/i.test(url);
  } catch {
    return false;
  }
}

function getUrl(item: PortfolioItem): string {
  try {
    return item.fileBlob.getDirectURL();
  } catch {
    return "/assets/images/placeholder.svg";
  }
}

// ── Skeleton ─────────────────────────────────────────────────────────────────

const SKELETON_KEYS = [
  "sk-a",
  "sk-b",
  "sk-c",
  "sk-d",
  "sk-e",
  "sk-f",
  "sk-g",
  "sk-h",
  "sk-i",
];
const SKELETON_HEIGHTS = [220, 300, 260, 340, 200, 280, 320, 240, 300];

function PortfolioSkeleton() {
  return (
    <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
      {SKELETON_KEYS.map((k, i) => (
        <div key={k} className="break-inside-avoid mb-4">
          <Skeleton
            className="w-full rounded-lg bg-secondary"
            style={{
              height: `${SKELETON_HEIGHTS[i % SKELETON_HEIGHTS.length]}px`,
            }}
          />
        </div>
      ))}
    </div>
  );
}

// ── Lightbox ──────────────────────────────────────────────────────────────────

interface LightboxProps {
  items: PortfolioItem[];
  index: number;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

function Lightbox({ items, index, onClose, onPrev, onNext }: LightboxProps) {
  const item = items[index];
  const video = isVideo(item);
  const url = getUrl(item);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose, onPrev, onNext]);

  // biome-ignore lint/correctness/useExhaustiveDependencies: index change signals new video item; videoRef is a stable ref
  useEffect(() => {
    videoRef.current?.load();
  }, [index]);

  return (
    <AnimatePresence>
      <motion.div
        key="lightbox-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm"
        onClick={onClose}
        data-ocid="portfolio.lightbox"
      >
        <button
          type="button"
          className="absolute left-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-card/60 hover:bg-primary/30 text-foreground transition-colors"
          onClick={(e) => {
            e.stopPropagation();
            onPrev();
          }}
          aria-label="Previous item"
          data-ocid="portfolio.lightbox_prev"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <button
          type="button"
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-card/60 hover:bg-primary/30 text-foreground transition-colors"
          onClick={onClose}
          aria-label="Close lightbox"
          data-ocid="portfolio.close_button"
        >
          <X className="w-6 h-6" />
        </button>

        <button
          type="button"
          className="absolute right-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-card/60 hover:bg-primary/30 text-foreground transition-colors"
          onClick={(e) => {
            e.stopPropagation();
            onNext();
          }}
          aria-label="Next item"
          data-ocid="portfolio.lightbox_next"
        >
          <ChevronRight className="w-6 h-6" />
        </button>

        <motion.div
          key={item.id.toString()}
          initial={{ scale: 0.92, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="relative max-w-5xl max-h-[80vh] w-full mx-16 flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {video ? (
            <video
              ref={videoRef}
              src={url}
              controls
              autoPlay
              className="w-full max-h-[70vh] rounded-lg object-contain bg-black"
            >
              <track kind="captions" />
            </video>
          ) : (
            <img
              src={url}
              alt={item.caption}
              className="w-full max-h-[70vh] rounded-lg object-contain"
            />
          )}

          <div className="mt-3 px-1 flex items-start justify-between gap-4">
            <div className="min-w-0">
              <p className="font-display text-lg text-foreground truncate">
                {item.caption}
              </p>
              {item.description && (
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                  {item.description}
                </p>
              )}
            </div>
            <Badge className="shrink-0 bg-primary/20 text-primary border-primary/40">
              {SERVICE_LABELS[item.category] ?? item.category}
            </Badge>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-2">
            {index + 1} / {items.length}
          </p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ── Grid Item ─────────────────────────────────────────────────────────────────

interface GridItemProps {
  item: PortfolioItem;
  index: number;
  onOpen: (index: number) => void;
}

function PortfolioGridItem({ item, index, onOpen }: GridItemProps) {
  const video = isVideo(item);
  const url = getUrl(item);
  const ocid = `portfolio.item.${index + 1}`;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.35, delay: Math.min(index * 0.06, 0.4) }}
      className="break-inside-avoid mb-4 group relative cursor-pointer rounded-lg overflow-hidden border border-border hover:border-primary/60 transition-colors duration-300"
      onClick={() => onOpen(index)}
      data-ocid={ocid}
    >
      {video ? (
        <div className="relative bg-black">
          <video
            src={url}
            muted
            preload="metadata"
            className="w-full object-cover block"
            style={{ maxHeight: "340px" }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-primary/80 flex items-center justify-center shadow-lg">
              <Play className="w-5 h-5 text-primary-foreground fill-current ml-0.5" />
            </div>
          </div>
        </div>
      ) : (
        <img
          src={url}
          alt={item.caption}
          loading="lazy"
          className="w-full object-cover block"
          style={{ maxHeight: "340px" }}
        />
      )}

      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
        <Badge className="self-start mb-2 bg-primary/90 text-primary-foreground border-0 text-xs">
          {SERVICE_LABELS[item.category] ?? item.category}
        </Badge>
        <p className="font-display text-sm text-white leading-snug line-clamp-2">
          {item.caption}
        </p>
      </div>
    </motion.div>
  );
}

// ── Empty State ───────────────────────────────────────────────────────────────

function EmptyState({ category }: { category: FilterKey }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-24 text-center"
      data-ocid="portfolio.empty_state"
    >
      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-6">
        <Play className="w-7 h-7 text-muted-foreground" />
      </div>
      <h3 className="font-display text-2xl text-foreground mb-2">
        No work here yet
      </h3>
      <p className="text-muted-foreground text-sm max-w-xs">
        {category === "all"
          ? "Portfolio items will appear here once uploaded from the admin panel."
          : `No ${SERVICE_LABELS[category] ?? category} work has been uploaded yet.`}
      </p>
    </motion.div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function Portfolio() {
  const navigate = useNavigate();
  const rawSearch = useSearch({ strict: false }) as Record<string, string>;
  const rawCategory = rawSearch?.category as string | undefined;

  const activeFilter = useMemo<FilterKey>(() => {
    if (!rawCategory || rawCategory === "all") return "all";
    const valid = Object.values(ServiceType) as string[];
    return valid.includes(rawCategory) ? (rawCategory as ServiceType) : "all";
  }, [rawCategory]);

  const backendCategory = activeFilter === "all" ? null : activeFilter;
  const { data: items = [], isLoading } = usePortfolio(backendCategory);

  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const handleFilterChange = useCallback(
    (key: FilterKey) => {
      void navigate({
        to: "/portfolio",
        search: key === "all" ? {} : { category: key },
      });
    },
    [navigate],
  );

  const openLightbox = useCallback(
    (index: number) => setLightboxIndex(index),
    [],
  );
  const closeLightbox = useCallback(() => setLightboxIndex(null), []);
  const prevItem = useCallback(
    () => setLightboxIndex((i) => (i !== null ? Math.max(0, i - 1) : null)),
    [],
  );
  const nextItem = useCallback(
    () =>
      setLightboxIndex((i) =>
        i !== null ? Math.min(items.length - 1, i + 1) : null,
      ),
    [items.length],
  );

  return (
    <Layout>
      <section className="min-h-screen bg-background py-20 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Page heading */}
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <p className="text-primary uppercase tracking-[0.25em] text-xs font-body mb-3">
              Our Work
            </p>
            <h1 className="font-display text-5xl md:text-6xl text-foreground leading-tight">
              Portfolio
            </h1>
            <div className="mt-4 mx-auto w-12 h-px bg-primary" />
          </motion.div>

          {/* Filter tabs */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="flex flex-wrap justify-center gap-2 mb-12"
            role="tablist"
            aria-label="Filter by category"
            data-ocid="portfolio.filter.tab"
          >
            {FILTER_TABS.map((tab) => (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={activeFilter === tab.key}
                onClick={() => handleFilterChange(tab.key)}
                data-ocid={`portfolio.tab.${tab.key.toLowerCase()}`}
                className={[
                  "px-5 py-2 rounded-full text-sm font-body font-medium transition-all duration-200 border",
                  activeFilter === tab.key
                    ? "bg-primary text-primary-foreground border-primary shadow-[0_0_16px_oklch(var(--primary)/0.4)]"
                    : "bg-transparent text-muted-foreground border-border hover:border-primary/50 hover:text-foreground",
                ].join(" ")}
              >
                {tab.label}
              </button>
            ))}
          </motion.div>

          {/* Grid / loading / empty */}
          {isLoading ? (
            <div data-ocid="portfolio.loading_state">
              <PortfolioSkeleton />
            </div>
          ) : items.length === 0 ? (
            <EmptyState category={activeFilter} />
          ) : (
            <AnimatePresence mode="popLayout">
              <div
                className="columns-1 sm:columns-2 lg:columns-3 gap-4"
                data-ocid="portfolio.list"
              >
                {items.map((item, idx) => (
                  <PortfolioGridItem
                    key={item.id.toString()}
                    item={item}
                    index={idx}
                    onOpen={openLightbox}
                  />
                ))}
              </div>
            </AnimatePresence>
          )}
        </div>
      </section>

      {/* Lightbox */}
      {lightboxIndex !== null && items.length > 0 && (
        <Lightbox
          items={items}
          index={lightboxIndex}
          onClose={closeLightbox}
          onPrev={prevItem}
          onNext={nextItem}
        />
      )}
    </Layout>
  );
}
