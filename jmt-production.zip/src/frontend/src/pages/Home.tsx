import type { ServiceType } from "@/backend";
import type { InquiryInput } from "@/backend";
import { Layout } from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useSubmitInquiry } from "@/hooks/useInquiries";
import { usePortfolio } from "@/hooks/usePortfolio";
import { getImageUrl } from "@/types";
import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Camera,
  CheckCircle,
  Clock,
  Film,
  Heart,
  Instagram,
  MessageCircle,
  Music,
  Package,
  Phone,
  Play,
  Share2,
  Star,
  Video,
  Youtube,
} from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import { SiFacebook } from "react-icons/si";
import { toast } from "sonner";

// ─── Data ───────────────────────────────────────────────────────────────────

const SERVICES = [
  {
    icon: Heart,
    title: "Wedding",
    description:
      "Timeless frames of your most cherished day — from vows to first dance, captured forever.",
    key: "Wedding",
  },
  {
    icon: Camera,
    title: "Fashion",
    description:
      "Editorial-grade shoots that speak to brands, designers, and model portfolios alike.",
    key: "Fashion",
  },
  {
    icon: Music,
    title: "Concert",
    description:
      "High-energy live event coverage — the raw energy, lights and crowd emotion in every shot.",
    key: "Concert",
  },
  {
    icon: Star,
    title: "Birthday",
    description:
      "Vibrant, joyful storytelling for milestone birthdays and intimate celebrations.",
    key: "Birthday",
  },
  {
    icon: Video,
    title: "Video Editing",
    description:
      "Color-graded, narrative-driven edits that transform raw footage into cinema-worthy reels.",
    key: "VideoEditing",
  },
  {
    icon: Share2,
    title: "Social Media",
    description:
      "Scroll-stopping content tailored for Instagram, YouTube, and beyond — optimised for engagement.",
    key: "SocialMedia",
  },
];

const VALUE_PROPS = [
  {
    icon: Package,
    title: "Professional Equipment",
    description:
      "We shoot with cinema-grade cameras, lenses, and lighting rigs — ensuring every frame is technically perfect.",
  },
  {
    icon: Film,
    title: "Expert Team",
    description:
      "Our directors, photographers, and editors bring years of industry experience to every production.",
  },
  {
    icon: Clock,
    title: "Timely Delivery",
    description:
      "We respect your timelines. Proofs within 72 hours, final deliverables exactly when promised.",
  },
];

const SERVICE_OPTIONS = [
  { value: "Wedding", label: "Wedding" },
  { value: "Fashion", label: "Fashion" },
  { value: "Concert", label: "Concert" },
  { value: "Birthday", label: "Birthday" },
  { value: "VideoEditing", label: "Video Editing" },
  { value: "SocialMedia", label: "Social Media" },
];

// ─── Sub-components ──────────────────────────────────────────────────────────

function HeroSection() {
  return (
    <section
      data-ocid="hero.section"
      className="relative min-h-screen flex flex-col items-center justify-center text-center overflow-hidden"
    >
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/generated/hero-cinematic-bg.dim_1920x1080.jpg"
          alt=""
          aria-hidden="true"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-background/75" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
      </div>

      <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent z-10" />

      <div className="relative z-10 max-w-5xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <img
            src="/assets/whatsapp_image_2026-05-18_at_1.51.31_am-removebg-preview_1-019e3b79-4fad-74da-ad18-0113e096e6a9.png"
            alt="JMT Production"
            className="h-20 mx-auto object-contain"
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
        >
          <Badge
            variant="outline"
            className="border-accent/60 text-accent mb-6 text-xs tracking-[0.25em] uppercase font-body px-4 py-1.5"
          >
            Photography &amp; Videography Studio
          </Badge>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.35 }}
          className="font-display text-5xl sm:text-7xl lg:text-8xl font-black uppercase leading-none tracking-tight text-foreground mb-6"
        >
          Crafting Visual
          <span className="block text-accent">Masterpieces.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="font-body text-lg text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          JMT Production delivers untouchable cinematic quality for discerning
          brands and individuals. Every frame is a story — told with precision,
          passion, and purpose.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.65 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Button
            asChild
            size="lg"
            className="bg-accent text-accent-foreground hover:bg-accent/90 font-body font-semibold tracking-wide uppercase text-sm px-8 py-6 transition-colors duration-200"
            data-ocid="hero.view_portfolio_button"
          >
            <Link to="/portfolio">
              View Our Work <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="border-accent/40 text-foreground hover:border-accent hover:bg-accent/5 font-body font-semibold tracking-wide uppercase text-sm px-8 py-6 transition-colors duration-200"
            data-ocid="hero.contact_button"
          >
            <Link to="/contact">Contact Us</Link>
          </Button>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
      >
        <div className="flex flex-col items-center gap-2">
          <span className="text-muted-foreground text-xs tracking-[0.2em] uppercase font-body">
            Scroll
          </span>
          <div className="w-0.5 h-10 bg-gradient-to-b from-accent to-transparent animate-pulse" />
        </div>
      </motion.div>
    </section>
  );
}

function ServicesSection() {
  return (
    <section
      data-ocid="services.section"
      id="services"
      className="py-24 bg-card"
    >
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <p className="text-accent font-body text-sm tracking-[0.25em] uppercase mb-3">
            What We Do
          </p>
          <h2 className="font-display text-4xl sm:text-5xl font-black uppercase text-foreground">
            Our Services
          </h2>
          <div className="w-16 h-0.5 bg-accent mx-auto mt-5" />
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((service, i) => (
            <motion.div
              key={service.key}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              data-ocid={`services.item.${i + 1}`}
            >
              <Card className="group bg-background border border-border hover:border-accent transition-colors duration-200 cursor-default h-full">
                <CardContent className="p-7 flex flex-col gap-4">
                  <div className="w-12 h-12 rounded-sm bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors duration-200">
                    <service.icon className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="font-display text-xl font-bold text-foreground">
                    {service.title}
                  </h3>
                  <p className="font-body text-muted-foreground text-sm leading-relaxed">
                    {service.description}
                  </p>
                  <div className="mt-auto pt-2">
                    <div className="w-0 h-0.5 bg-accent group-hover:w-full transition-all duration-500" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function PortfolioPreviewSection() {
  const { data: items, isLoading } = usePortfolio();
  const latest = (items ?? []).slice(0, 4);

  return (
    <section
      data-ocid="portfolio_preview.section"
      id="portfolio-preview"
      className="py-24 bg-background"
    >
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-14"
        >
          <div>
            <p className="text-accent font-body text-sm tracking-[0.25em] uppercase mb-3">
              Portfolio
            </p>
            <h2 className="font-display text-4xl sm:text-5xl font-black uppercase text-foreground leading-none">
              Selected
              <span className="block text-muted-foreground">Works</span>
            </h2>
            <div className="w-16 h-0.5 bg-accent mt-5" />
          </div>
          <Button
            asChild
            variant="ghost"
            className="border border-accent/30 text-accent hover:bg-accent/10 hover:border-accent font-body uppercase tracking-wide text-sm transition-colors duration-200"
            data-ocid="portfolio_preview.view_all_button"
          >
            <Link to="/portfolio">
              View All Work <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </motion.div>

        {isLoading ? (
          <div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
            data-ocid="portfolio_preview.loading_state"
          >
            {[1, 2, 3, 4].map((n) => (
              <Skeleton key={n} className="w-full aspect-[3/4] rounded-sm" />
            ))}
          </div>
        ) : latest.length === 0 ? (
          <div
            data-ocid="portfolio_preview.empty_state"
            className="flex flex-col items-center justify-center py-24 text-center border border-dashed border-border rounded-sm"
          >
            <Camera className="w-12 h-12 text-accent/30 mb-4" />
            <p className="font-display text-xl text-muted-foreground mb-2">
              Portfolio coming soon
            </p>
            <p className="font-body text-sm text-muted-foreground/60">
              Our best work will appear here once uploaded.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {latest.map((item, i) => (
              <motion.div
                key={String(item.id)}
                initial={{ opacity: 0, scale: 0.96 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                data-ocid={`portfolio_preview.item.${i + 1}`}
                className="group relative overflow-hidden rounded-sm aspect-[3/4] bg-card border border-border hover:border-accent transition-colors duration-200 cursor-pointer"
              >
                <Link
                  to="/portfolio"
                  className="absolute inset-0 z-10"
                  aria-label={item.caption}
                />
                <img
                  src={getImageUrl(item.fileBlob)}
                  alt={item.caption}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-200">
                  <Badge
                    variant="outline"
                    className="border-accent/60 text-accent text-xs mb-2"
                  >
                    {String(item.category)}
                  </Badge>
                  <p className="font-display text-sm font-bold text-foreground line-clamp-2">
                    {item.caption}
                  </p>
                </div>
                {/\.(mp4|mov|webm|avi|mkv)$/i.test(
                  item.caption + item.fileBlob?.getDirectURL?.(),
                ) && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-10 h-10 rounded-full bg-accent/20 border border-accent/60 flex items-center justify-center">
                      <Play className="w-4 h-4 text-accent ml-0.5" />
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function WhyChooseUsSection() {
  return (
    <section data-ocid="why_choose.section" className="py-24 bg-card">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <p className="text-accent font-body text-sm tracking-[0.25em] uppercase mb-3">
            Why JMT
          </p>
          <h2 className="font-display text-4xl sm:text-5xl font-black uppercase text-foreground">
            Why Choose Us
          </h2>
          <div className="w-16 h-0.5 bg-accent mx-auto mt-5" />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {VALUE_PROPS.map((vp, i) => (
            <motion.div
              key={vp.title}
              initial={{
                opacity: 0,
                x: i === 0 ? -30 : i === 2 ? 30 : 0,
                y: i === 1 ? 30 : 0,
              }}
              whileInView={{ opacity: 1, x: 0, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.15 }}
              data-ocid={`why_choose.item.${i + 1}`}
              className="flex flex-col items-center text-center gap-5"
            >
              <div className="w-16 h-16 rounded-sm border border-accent/30 bg-accent/5 flex items-center justify-center">
                <vp.icon className="w-8 h-8 text-accent" />
              </div>
              <div>
                <h3 className="font-display text-xl font-bold text-foreground mb-2">
                  {vp.title}
                </h3>
                <p className="font-body text-muted-foreground text-sm leading-relaxed">
                  {vp.description}
                </p>
              </div>
              <CheckCircle className="w-5 h-5 text-accent/50" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function InquiryFormSection() {
  const submitInquiry = useSubmitInquiry();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    serviceType: "" as ServiceType | "",
    message: "",
  });

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >,
  ) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.serviceType || !form.message) {
      toast.error("Please fill all required fields.");
      return;
    }
    const input: InquiryInput = {
      name: form.name,
      email: form.email,
      phone: form.phone,
      serviceType: form.serviceType as ServiceType,
      message: form.message,
    };
    submitInquiry.mutate(input, {
      onSuccess: () => {
        toast.success("Inquiry sent! We'll get back to you shortly.");
        setForm({
          name: "",
          email: "",
          phone: "",
          serviceType: "",
          message: "",
        });
      },
      onError: () => toast.error("Something went wrong. Please try again."),
    });
  };

  return (
    <section
      data-ocid="inquiry.section"
      id="inquiry"
      className="py-24 bg-background"
    >
      <div className="max-w-3xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <p className="text-accent font-body text-sm tracking-[0.25em] uppercase mb-3">
            Get In Touch
          </p>
          <h2 className="font-display text-4xl sm:text-5xl font-black uppercase text-foreground">
            Book a Shoot
          </h2>
          <div className="w-16 h-0.5 bg-accent mx-auto mt-5" />
          <p className="font-body text-muted-foreground mt-5 text-sm">
            Tell us about your project and we'll get back to you within 24
            hours.
          </p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.15 }}
          onSubmit={handleSubmit}
          className="bg-card border border-border rounded-sm p-8 flex flex-col gap-5"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="inq-name"
                className="font-body text-xs uppercase tracking-widest text-muted-foreground"
              >
                Name <span className="text-accent">*</span>
              </label>
              <input
                id="inq-name"
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Your full name"
                className="bg-background border border-input rounded-sm px-4 py-3 text-sm font-body text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent transition-colors duration-200"
                data-ocid="inquiry.name_input"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="inq-email"
                className="font-body text-xs uppercase tracking-widest text-muted-foreground"
              >
                Email <span className="text-accent">*</span>
              </label>
              <input
                id="inq-email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                placeholder="your@email.com"
                className="bg-background border border-input rounded-sm px-4 py-3 text-sm font-body text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent transition-colors duration-200"
                data-ocid="inquiry.email_input"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="inq-phone"
                className="font-body text-xs uppercase tracking-widest text-muted-foreground"
              >
                Phone
              </label>
              <input
                id="inq-phone"
                name="phone"
                type="tel"
                value={form.phone}
                onChange={handleChange}
                placeholder="+91 00000 00000"
                className="bg-background border border-input rounded-sm px-4 py-3 text-sm font-body text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent transition-colors duration-200"
                data-ocid="inquiry.phone_input"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="inq-service"
                className="font-body text-xs uppercase tracking-widest text-muted-foreground"
              >
                Service <span className="text-accent">*</span>
              </label>
              <select
                id="inq-service"
                name="serviceType"
                value={form.serviceType}
                onChange={handleChange}
                className="bg-background border border-input rounded-sm px-4 py-3 text-sm font-body text-foreground focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent transition-colors duration-200 appearance-none"
                data-ocid="inquiry.service_select"
              >
                <option value="" disabled>
                  Select a service
                </option>
                {SERVICE_OPTIONS.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="inq-message"
              className="font-body text-xs uppercase tracking-widest text-muted-foreground"
            >
              Message <span className="text-accent">*</span>
            </label>
            <textarea
              id="inq-message"
              name="message"
              value={form.message}
              onChange={handleChange}
              rows={4}
              placeholder="Tell us about your shoot, date, location and any special requirements..."
              className="bg-background border border-input rounded-sm px-4 py-3 text-sm font-body text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent transition-colors duration-200 resize-none"
              data-ocid="inquiry.message_textarea"
            />
          </div>

          <Button
            type="submit"
            disabled={submitInquiry.isPending}
            className="bg-accent text-accent-foreground hover:bg-accent/90 font-body font-semibold uppercase tracking-wide text-sm py-6 transition-colors duration-200 mt-2"
            data-ocid="inquiry.submit_button"
          >
            {submitInquiry.isPending ? "Sending..." : "Send Inquiry"}
          </Button>

          {submitInquiry.isError && (
            <p
              className="text-destructive text-sm text-center font-body"
              data-ocid="inquiry.error_state"
            >
              Something went wrong. Please try again.
            </p>
          )}
          {submitInquiry.isSuccess && (
            <p
              className="text-accent text-sm text-center font-body"
              data-ocid="inquiry.success_state"
            >
              ✓ Inquiry sent successfully!
            </p>
          )}
        </motion.form>
      </div>
    </section>
  );
}

function CtaBannerSection() {
  return (
    <section
      data-ocid="cta.section"
      className="py-20 bg-card border-y border-accent/20"
    >
      <div className="max-w-5xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="border border-accent/30 rounded-sm px-8 py-14 text-center relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-accent" />
          <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-accent" />
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-accent" />
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-accent" />

          <p className="text-accent font-body text-sm tracking-[0.25em] uppercase mb-4">
            Let's Create Together
          </p>
          <h2 className="font-display text-3xl sm:text-5xl font-black uppercase text-foreground mb-4">
            Ready to Create
            <span className="text-accent block">Something Amazing?</span>
          </h2>
          <p className="font-body text-muted-foreground text-sm max-w-xl mx-auto mb-10">
            Reach out via WhatsApp for a quick chat, or drop us a message and
            we'll get back to you within 24 hours.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-[#25D366] text-foreground hover:bg-[#25D366]/90 font-body font-semibold uppercase tracking-wide text-sm px-8 py-6 transition-colors duration-200"
              data-ocid="cta.whatsapp_button"
            >
              <a
                href="https://wa.me/919330181029"
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="mr-2 w-4 h-4" />
                WhatsApp Us
              </a>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-accent/40 text-foreground hover:border-accent hover:bg-accent/5 font-body font-semibold uppercase tracking-wide text-sm px-8 py-6 transition-colors duration-200"
              data-ocid="cta.call_button"
            >
              <a href="tel:+916289976250">
                <Phone className="mr-2 w-4 h-4" />
                Call Now
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 font-body font-semibold uppercase tracking-wide text-sm px-8 py-6 transition-colors duration-200"
              data-ocid="cta.contact_page_button"
            >
              <Link to="/contact">Contact Page</Link>
            </Button>
          </div>

          <div className="flex items-center justify-center gap-6 mt-10">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="text-muted-foreground hover:text-accent transition-colors duration-200"
              data-ocid="cta.instagram_link"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
              className="text-muted-foreground hover:text-accent transition-colors duration-200"
              data-ocid="cta.youtube_link"
            >
              <Youtube className="w-5 h-5" />
            </a>
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
              className="text-muted-foreground hover:text-accent transition-colors duration-200"
              data-ocid="cta.facebook_link"
            >
              <SiFacebook className="w-5 h-5" />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <Layout>
      <HeroSection />
      <ServicesSection />
      <PortfolioPreviewSection />
      <WhyChooseUsSection />
      <InquiryFormSection />
      <CtaBannerSection />
    </Layout>
  );
}
