import type { ServiceType } from "@/backend";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useSubmitInquiry } from "@/hooks/useInquiries";
import { SERVICE_LABELS } from "@/types";
import { CheckCircle2, MessageCircle, Phone } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import { SiFacebook, SiInstagram, SiYoutube } from "react-icons/si";
import { toast } from "sonner";

const SERVICE_OPTIONS = Object.entries(SERVICE_LABELS).map(
  ([value, label]) => ({ value, label }),
);

const SOCIAL_LINKS = [
  {
    icon: SiInstagram,
    label: "Instagram",
    href: "https://www.instagram.com/jmt.production",
    ocid: "contact.instagram_link",
  },
  {
    icon: SiYoutube,
    label: "YouTube",
    href: "https://www.youtube.com/@jmtproduction",
    ocid: "contact.youtube_link",
  },
  {
    icon: SiFacebook,
    label: "Facebook",
    href: "https://www.facebook.com/jmtproduction",
    ocid: "contact.facebook_link",
  },
];

export default function Contact() {
  const { mutate: submit, isPending } = useSubmitInquiry();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    serviceType: "" as string,
    message: "",
  });
  const [errors, setErrors] = useState<Partial<typeof form>>({});

  const validate = () => {
    const e: Partial<typeof form> = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email))
      e.email = "Valid email required";
    if (!form.phone.trim()) e.phone = "Phone number is required";
    if (!form.serviceType) e.serviceType = "Please select a service";
    if (!form.message.trim()) e.message = "Message is required";
    return e;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    submit(
      {
        name: form.name,
        email: form.email,
        phone: form.phone,
        serviceType: form.serviceType as ServiceType,
        message: form.message,
      },
      {
        onSuccess: () => {
          setSubmitted(true);
          toast.success("Inquiry sent! We'll reach out soon.");
        },
        onError: () => {
          toast.error("Something went wrong. Please try again.");
        },
      },
    );
  };

  return (
    <Layout>
      {/* Page header */}
      <section
        className="relative bg-card border-b border-border/40 py-14 px-4 overflow-hidden"
        data-ocid="contact.header_section"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <p className="text-xs tracking-[0.35em] uppercase text-primary mb-3">
              Let's Create Together
            </p>
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-foreground uppercase leading-none">
              Contact Us
            </h1>
            <div className="w-16 h-px bg-primary mx-auto mt-6" />
          </motion.div>
        </div>
      </section>

      {/* Two-column layout */}
      <section
        className="bg-background py-20 px-4"
        data-ocid="contact.main_section"
      >
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-0 border border-border/30">
          {/* LEFT: Contact info panel */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-2 bg-card border-b lg:border-b-0 lg:border-r border-border/30 p-8 lg:p-10 flex flex-col gap-9"
          >
            {/* Branding */}
            <div className="flex flex-col gap-3">
              <img
                src="/assets/whatsapp_image_2026-05-18_at_1.51.31_am-removebg-preview_1-019e3b79-4fad-74da-ad18-0113e096e6a9.png"
                alt="JMT Production"
                className="h-14 w-auto object-contain"
              />
              <p className="text-muted-foreground text-sm leading-relaxed">
                Cinematic visuals for weddings, fashion, concerts, and beyond.
                Reach out and let's turn your vision into something
                unforgettable.
              </p>
            </div>

            <div className="w-full h-px bg-border/40" />

            {/* Contact buttons */}
            <div className="flex flex-col gap-3">
              <p className="text-xs tracking-[0.25em] uppercase text-primary">
                Get In Touch
              </p>
              <a
                href="https://wa.me/919330181029"
                target="_blank"
                rel="noopener noreferrer"
                data-ocid="contact.whatsapp_button"
                className="group flex items-center gap-4 p-4 border border-[#25D366]/20 bg-[#25D366]/5 hover:bg-[#25D366]/10 hover:border-[#25D366]/40 transition-all duration-300"
              >
                <div className="w-11 h-11 rounded-full bg-[#25D366]/15 flex items-center justify-center flex-shrink-0 group-hover:bg-[#25D366]/25 transition-colors">
                  <MessageCircle className="w-5 h-5 text-[#25D366]" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] text-[#25D366] uppercase tracking-widest mb-0.5">
                    WhatsApp
                  </p>
                  <p className="text-foreground font-semibold text-sm">
                    +91 93301 81029
                  </p>
                </div>
                <span className="ml-auto text-[#25D366]/40 group-hover:text-[#25D366]/80 text-xs transition-colors">
                  ↗
                </span>
              </a>
              <a
                href="tel:+916289976250"
                data-ocid="contact.phone_button"
                className="group flex items-center gap-4 p-4 border border-primary/20 bg-primary/5 hover:bg-primary/10 hover:border-primary/40 transition-all duration-300"
              >
                <div className="w-11 h-11 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/25 transition-colors">
                  <Phone className="w-5 h-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] text-primary uppercase tracking-widest mb-0.5">
                    Call Us
                  </p>
                  <p className="text-foreground font-semibold text-sm">
                    +91 6289 976 250
                  </p>
                </div>
                <span className="ml-auto text-primary/40 group-hover:text-primary/80 text-xs transition-colors">
                  ↗
                </span>
              </a>
            </div>

            <div className="w-full h-px bg-border/40" />

            {/* Social links */}
            <div className="flex flex-col gap-4">
              <p className="text-xs tracking-[0.25em] uppercase text-primary">
                Follow Our Work
              </p>
              <div className="flex items-center gap-3">
                {SOCIAL_LINKS.map(({ icon: Icon, label, href, ocid }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={label}
                    data-ocid={ocid}
                    className="w-10 h-10 flex items-center justify-center border border-border/40 text-muted-foreground hover:text-primary hover:border-primary/50 hover:bg-primary/5 transition-all duration-200"
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                ))}
              </div>
            </div>

            {/* Availability note */}
            <div className="mt-auto flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#25D366] animate-pulse" />
              <p className="text-xs text-muted-foreground">
                Available for bookings — responds within 24 hrs
              </p>
            </div>
          </motion.div>

          {/* RIGHT: Inquiry form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.12 }}
            className="lg:col-span-3 bg-background p-8 lg:p-10"
          >
            {submitted ? (
              <div
                className="flex flex-col items-center justify-center gap-5 py-16 text-center h-full"
                data-ocid="contact.success_state"
              >
                <div className="w-20 h-20 rounded-full border border-primary/30 bg-primary/10 flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10 text-primary" />
                </div>
                <div>
                  <h3 className="font-display text-3xl font-bold text-primary uppercase mb-2">
                    Message Sent!
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    Thank you for reaching out to JMT Production.
                    <br />
                    We'll get back to you within 24 hours.
                  </p>
                </div>
                <div className="w-12 h-px bg-primary/40" />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setSubmitted(false);
                    setForm({
                      name: "",
                      email: "",
                      phone: "",
                      serviceType: "",
                      message: "",
                    });
                  }}
                  className="border-primary/30 text-primary hover:bg-primary/10 hover:border-primary text-xs tracking-widest uppercase"
                >
                  Send Another Inquiry
                </Button>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="flex flex-col gap-6"
                data-ocid="contact.inquiry_form"
              >
                <div>
                  <h2 className="font-display text-2xl font-bold text-foreground uppercase mb-1">
                    Send an Inquiry
                  </h2>
                  <p className="text-muted-foreground text-xs tracking-wide">
                    Fill in the details below — all fields are required.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FieldGroup id="name" label="Full Name" error={errors.name}>
                    <Input
                      id="name"
                      value={form.name}
                      onChange={(e) =>
                        setForm({ ...form, name: e.target.value })
                      }
                      placeholder="Your full name"
                      className="bg-card border-border/60 focus:border-primary focus-visible:ring-primary/20"
                      data-ocid="contact.name_input"
                    />
                  </FieldGroup>
                  <FieldGroup
                    id="email"
                    label="Email Address"
                    error={errors.email}
                  >
                    <Input
                      id="email"
                      type="email"
                      value={form.email}
                      onChange={(e) =>
                        setForm({ ...form, email: e.target.value })
                      }
                      placeholder="you@example.com"
                      className="bg-card border-border/60 focus:border-primary focus-visible:ring-primary/20"
                      data-ocid="contact.email_input"
                    />
                  </FieldGroup>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FieldGroup
                    id="phone"
                    label="Phone Number"
                    error={errors.phone}
                  >
                    <Input
                      id="phone"
                      type="tel"
                      value={form.phone}
                      onChange={(e) =>
                        setForm({ ...form, phone: e.target.value })
                      }
                      placeholder="+91 XXXXX XXXXX"
                      className="bg-card border-border/60 focus:border-primary focus-visible:ring-primary/20"
                      data-ocid="contact.phone_input"
                    />
                  </FieldGroup>
                  <FieldGroup
                    id="service"
                    label="Service Type"
                    error={errors.serviceType}
                  >
                    <Select
                      value={form.serviceType}
                      onValueChange={(v) =>
                        setForm({ ...form, serviceType: v })
                      }
                    >
                      <SelectTrigger
                        className="bg-card border-border/60 focus:ring-primary/20"
                        data-ocid="contact.service_select"
                      >
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border/50">
                        {SERVICE_OPTIONS.map(({ value, label }) => (
                          <SelectItem key={value} value={value}>
                            {label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FieldGroup>
                </div>

                <FieldGroup
                  id="message"
                  label="Your Message"
                  error={errors.message}
                >
                  <Textarea
                    id="message"
                    value={form.message}
                    onChange={(e) =>
                      setForm({ ...form, message: e.target.value })
                    }
                    placeholder="Tell us about your project — event date, location, style, and any special requirements..."
                    rows={5}
                    className="bg-card border-border/60 focus:border-primary focus-visible:ring-primary/20 resize-none"
                    data-ocid="contact.message_textarea"
                  />
                </FieldGroup>

                <Button
                  type="submit"
                  disabled={isPending}
                  className="cta-button w-full py-3.5 text-xs tracking-[0.2em] uppercase font-semibold"
                  data-ocid="contact.submit_button"
                >
                  {isPending ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      Sending…
                    </span>
                  ) : (
                    "Send Inquiry"
                  )}
                </Button>
                {isPending && (
                  <p
                    className="text-center text-xs text-muted-foreground"
                    data-ocid="contact.loading_state"
                  >
                    Submitting your inquiry…
                  </p>
                )}
              </form>
            )}
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}

function FieldGroup({
  id,
  label,
  error,
  children,
}: { id: string; label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label
        htmlFor={id}
        className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground"
      >
        {label}
      </Label>
      {children}
      {error && (
        <p
          className="text-xs text-destructive"
          data-ocid={`contact.${id}_field_error`}
        >
          {error}
        </p>
      )}
    </div>
  );
}
