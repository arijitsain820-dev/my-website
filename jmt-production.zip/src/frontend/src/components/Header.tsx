import { useAuth } from "@/hooks/useAuth";
import { useLogoSrc } from "@/hooks/useBranding";
import { Link, useLocation } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";

const NAV_LINKS = [
  { label: "Home", to: "/" },
  { label: "Portfolio", to: "/portfolio" },
  { label: "Team", to: "/team" },
  { label: "Contact", to: "/contact" },
] as const;

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { isAuthenticated, login, logout, isInitializing, isLoggingIn } =
    useAuth();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const logoSrc = useLogoSrc();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-card border-b border-border/50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center gap-3 group"
            data-ocid="header.logo_link"
          >
            <img
              src={logoSrc}
              alt="JMT Production Logo"
              className="h-10 w-auto object-contain"
            />
            <div className="hidden sm:block">
              <span className="font-display text-xl font-bold tracking-tight text-foreground">
                JMT
              </span>
              <span className="text-xs tracking-[0.25em] text-muted-foreground uppercase ml-1.5">
                Production
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                data-ocid={`header.${link.label.toLowerCase()}_link`}
                className={`text-sm tracking-widest uppercase font-medium transition-colors duration-200 ${
                  isActive(link.to)
                    ? "text-primary border-b border-primary pb-0.5"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {link.label}
              </Link>
            ))}
            {isAuthenticated && (
              <Link
                to="/admin"
                data-ocid="header.admin_link"
                className={`text-sm tracking-widest uppercase font-medium transition-colors duration-200 ${
                  isActive("/admin")
                    ? "text-primary border-b border-primary pb-0.5"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Admin
              </Link>
            )}
          </nav>

          {/* CTA + Mobile toggle */}
          <div className="flex items-center gap-3">
            <a
              href="https://wa.me/919330181029"
              target="_blank"
              rel="noopener noreferrer"
              data-ocid="header.whatsapp_button"
              className="hidden md:inline-flex cta-button px-4 py-2 text-xs tracking-widest uppercase"
            >
              Get a Quote
            </a>
            {isAuthenticated ? (
              <button
                type="button"
                onClick={logout}
                data-ocid="header.logout_button"
                className="hidden md:inline-flex text-xs tracking-widest uppercase text-muted-foreground hover:text-foreground transition-colors"
              >
                Logout
              </button>
            ) : (
              <button
                type="button"
                onClick={login}
                disabled={isInitializing || isLoggingIn}
                data-ocid="header.login_button"
                className="hidden md:inline-flex text-xs tracking-widest uppercase text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
              >
                {isInitializing ? "Loading…" : "Admin"}
              </button>
            )}
            <button
              type="button"
              className="md:hidden text-foreground"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
              data-ocid="header.mobile_menu_toggle"
            >
              {mobileOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden bg-card border-t border-border/50 px-4 py-4 flex flex-col gap-4">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              onClick={() => setMobileOpen(false)}
              data-ocid={`header.mobile_${link.label.toLowerCase()}_link`}
              className={`text-sm tracking-widest uppercase font-medium py-1 ${
                isActive(link.to) ? "text-primary" : "text-muted-foreground"
              }`}
            >
              {link.label}
            </Link>
          ))}
          {isAuthenticated && (
            <Link
              to="/admin"
              onClick={() => setMobileOpen(false)}
              data-ocid="header.mobile_admin_link"
              className={`text-sm tracking-widest uppercase font-medium py-1 ${
                isActive("/admin") ? "text-primary" : "text-muted-foreground"
              }`}
            >
              Admin
            </Link>
          )}
          <a
            href="https://wa.me/919330181029"
            target="_blank"
            rel="noopener noreferrer"
            className="cta-button px-4 py-2 text-xs tracking-widest uppercase text-center mt-2"
          >
            Get a Quote
          </a>
        </div>
      )}
    </header>
  );
}
