import { useAuth, useIsAdmin } from "@/hooks/useAuth";
import { Loader2, ShieldOff } from "lucide-react";
import type { ReactNode } from "react";

interface ProtectedRouteProps {
  children: ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated, isInitializing, login } = useAuth();
  const { data: isAdmin, isLoading: adminLoading } = useIsAdmin();

  if (isInitializing || adminLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-6 px-4">
        <ShieldOff className="w-16 h-16 text-primary" />
        <h1 className="font-display text-3xl text-foreground text-center">
          Admin Access Required
        </h1>
        <p className="text-muted-foreground text-center max-w-md">
          Sign in with Internet Identity to access the admin panel.
        </p>
        <button
          type="button"
          onClick={login}
          data-ocid="admin.login_button"
          className="cta-button px-8 py-3 text-sm font-semibold tracking-widest uppercase"
        >
          Login with Internet Identity
        </button>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-6 px-4">
        <ShieldOff className="w-16 h-16 text-destructive" />
        <h1 className="font-display text-3xl text-foreground text-center">
          Access Denied
        </h1>
        <p className="text-muted-foreground text-center max-w-md">
          You do not have admin privileges. Contact the site administrator.
        </p>
      </div>
    );
  }

  return <>{children}</>;
}
