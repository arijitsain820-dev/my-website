import { useLogoSrc } from "@/hooks/useBranding";
import { Link } from "@tanstack/react-router";
import { Phone } from "lucide-react";
import { SiFacebook, SiInstagram, SiYoutube } from "react-icons/si";

const FOOTER_LINKS = [
  { label: "Home", to: "/" },
  { label: "Portfolio", to: "/portfolio" },
  { label: "Team", to: "/team" },
  { label: "Contact", to: "/contact" },
];

const SOCIAL = [
  {
    icon: SiInstagram,
    label: "Instagram",
    href: "https://www.instagram.com/jmt.production",
    ocid: "footer.instagram_link",
  },
  {
    icon: SiYoutube,
    label: "YouTube",
    href: "https://www.youtube.com/@jmtproduction",
    ocid: "footer.youtube_link",
  },
  {
    icon: SiFacebook,
    label: "Facebook",
    href: "https://www.facebook.com/jmtproduction",
    ocid: "footer.facebook_link",
  },
];

export function Footer() {
  const year = new Date().getFullYear();
  const logoSrc = useLogoSrc();
  const hostname =
    typeof window !== "undefined" ? window.location.hostname : "";
  const caffeineLink = `https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(hostname)}`;

  return (
    <footer className="bg-card border-t border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <div className="flex flex-col gap-4">
            <Link to="/" className="flex items-center gap-3">
              <img
                src={logoSrc}
                alt="JMT Production"
                className="h-12 w-auto object-contain"
              />
              <div>
                <div className="font-display text-xl font-bold text-foreground">
                  JMT
                </div>
                <div className="text-xs tracking-[0.25em] text-muted-foreground uppercase">
                  Production
                </div>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
              Cinematic photography &amp; videography for weddings, fashion,
              concerts, birthdays and social media.
            </p>
            <div className="flex items-center gap-4 mt-2">
              {SOCIAL.map(({ icon: Icon, label, href, ocid }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  data-ocid={ocid}
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Nav */}
          <div>
            <h4 className="text-xs tracking-[0.2em] uppercase text-primary font-semibold mb-4">
              Navigation
            </h4>
            <ul className="flex flex-col gap-2">
              {FOOTER_LINKS.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xs tracking-[0.2em] uppercase text-primary font-semibold mb-4">
              Contact Us
            </h4>
            <div className="flex flex-col gap-3">
              <a
                href="https://wa.me/919330181029"
                target="_blank"
                rel="noopener noreferrer"
                data-ocid="footer.whatsapp_button"
                className="flex items-center gap-3 group"
              >
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-[#25D366]/10 group-hover:bg-[#25D366]/20 transition-colors">
                  <svg
                    viewBox="0 0 24 24"
                    className="w-4 h-4 fill-[#25D366]"
                    role="img"
                    aria-label="WhatsApp"
                  >
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" />
                    <path d="M12 0C5.373 0 0 5.373 0 12c0 2.125.555 4.122 1.528 5.857L0 24l6.335-1.652A11.954 11.954 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.015-1.376l-.36-.213-3.735.975.999-3.645-.235-.374A9.818 9.818 0 012.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z" />
                  </svg>
                </span>
                <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                  +91 93301 81029
                </span>
              </a>
              <a
                href="tel:+916289976250"
                data-ocid="footer.phone_button"
                className="flex items-center gap-3 group"
              >
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  <Phone className="w-4 h-4 text-primary" />
                </span>
                <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                  +91 6289 976 250
                </span>
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-border/30 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            © {year} JMT Production. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Built with love using{" "}
            <a
              href={caffeineLink}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-primary transition-colors"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
