import { createActor } from "@/backend";
import type { PortfolioItem, ServiceType } from "@/backend";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export function usePortfolio(category?: ServiceType | null) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<PortfolioItem[]>({
    queryKey: ["portfolio", category ?? "all"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.listPortfolioItems(category ?? null);
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddPortfolioItem() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (vars: {
      fileBlob: import("@/backend").ExternalBlob;
      category: ServiceType;
      caption: string;
      description: string;
    }) => {
      if (!actor) throw new Error("Actor not available");
      return actor.addPortfolioItem(
        vars.fileBlob,
        vars.category,
        vars.caption,
        vars.description,
      );
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["portfolio"] }),
  });
}

export function useDeletePortfolioItem() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error("Actor not available");
      return actor.deletePortfolioItem(id);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["portfolio"] }),
  });
}
