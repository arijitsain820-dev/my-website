import { ExternalBlob, createActor } from "@/backend";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

const FALLBACK_LOGO =
  "/assets/whatsapp_image_2026-05-18_at_1.51.31_am-removebg-preview_1-019e3b79-4fad-74da-ad18-0113e096e6a9.png";

export function useLogoUrl() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<string | null>({
    queryKey: ["branding", "logo"],
    queryFn: async () => {
      if (!actor) return null;
      const result = await actor.getBrandingLogo();
      if (result === null) return null;
      try {
        return result.getDirectURL();
      } catch {
        return null;
      }
    },
    enabled: !!actor && !isFetching,
    select: (url) => url ?? null,
  });
}

export function useLogoSrc() {
  const { data } = useLogoUrl();
  return data ?? FALLBACK_LOGO;
}

export function useSetBrandingLogo() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (vars: {
      file: File;
      onProgress?: (p: number) => void;
    }) => {
      if (!actor) throw new Error("Actor not available");
      const bytes = new Uint8Array(await vars.file.arrayBuffer());
      let blob = ExternalBlob.fromBytes(bytes);
      if (vars.onProgress) {
        blob = blob.withUploadProgress(vars.onProgress);
      }
      return actor.setBrandingLogo(blob);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["branding", "logo"] }),
  });
}
