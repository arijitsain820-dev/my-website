import { createActor } from "@/backend";
import type { ExternalBlob, TeamMember } from "@/backend";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export function useTeam() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<TeamMember[]>({
    queryKey: ["team"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.listTeamMembers();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddTeamMember() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (vars: {
      name: string;
      role: string;
      photoBlob: ExternalBlob;
      bio: string;
      order: bigint;
    }) => {
      if (!actor) throw new Error("Actor not available");
      return actor.addTeamMember(
        vars.name,
        vars.role,
        vars.photoBlob,
        vars.bio,
        vars.order,
      );
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["team"] }),
  });
}

export function useUpdateTeamMember() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (vars: {
      id: bigint;
      name: string;
      role: string;
      photoBlob: ExternalBlob;
      bio: string;
      order: bigint;
    }) => {
      if (!actor) throw new Error("Actor not available");
      return actor.updateTeamMember(
        vars.id,
        vars.name,
        vars.role,
        vars.photoBlob,
        vars.bio,
        vars.order,
      );
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["team"] }),
  });
}

export function useDeleteTeamMember() {
  const { actor } = useActor(createActor);
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error("Actor not available");
      return actor.deleteTeamMember(id);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["team"] }),
  });
}
