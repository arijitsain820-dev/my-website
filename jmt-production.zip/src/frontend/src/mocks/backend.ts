import type { backendInterface, PortfolioItem, TeamMember, Inquiry, InquiryInput } from "../backend";
import { ServiceType, UserRole, ExternalBlob } from "../backend";
import type { Principal } from "@icp-sdk/core/principal";

const makeBlob = (url: string): ExternalBlob => ExternalBlob.fromURL(url);

const portfolioItems: PortfolioItem[] = [
  {
    id: BigInt(1),
    createdAt: BigInt(Date.now()),
    fileBlob: makeBlob("https://images.unsplash.com/photo-1519741497674-611481863552?w=800"),
    caption: "Golden Moments",
    description: "Elegant wedding ceremony captured in warm cinematic tones.",
    category: ServiceType.Wedding,
  },
  {
    id: BigInt(2),
    createdAt: BigInt(Date.now()),
    fileBlob: makeBlob("https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800"),
    caption: "Landscape Redefined",
    description: "Dramatic landscape with cinematic golden hour lighting.",
    category: ServiceType.Concert,
  },
  {
    id: BigInt(3),
    createdAt: BigInt(Date.now()),
    fileBlob: makeBlob("https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=800"),
    caption: "Fashion Forward",
    description: "Editorial fashion photography with bold, dramatic style.",
    category: ServiceType.Fashion,
  },
  {
    id: BigInt(4),
    createdAt: BigInt(Date.now()),
    fileBlob: makeBlob("https://images.unsplash.com/photo-1527529482837-4698179dc6ce?w=800"),
    caption: "Birthday Celebrations",
    description: "Vibrant birthday moments captured with cinematic flair.",
    category: ServiceType.Birthday,
  },
  {
    id: BigInt(5),
    createdAt: BigInt(Date.now()),
    fileBlob: makeBlob("https://images.unsplash.com/photo-1574717024453-354956afc159?w=800"),
    caption: "Social Media Magic",
    description: "Scroll-stopping content for Instagram and YouTube.",
    category: ServiceType.SocialMedia,
  },
  {
    id: BigInt(6),
    createdAt: BigInt(Date.now()),
    fileBlob: makeBlob("https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800"),
    caption: "Concert Energy",
    description: "Electric concert atmosphere captured in high drama.",
    category: ServiceType.Concert,
  },
];

const teamMembers: TeamMember[] = [
  {
    id: BigInt(1),
    name: "Rahul Sharma",
    role: "Lead Cinematographer",
    bio: "7+ years capturing cinematic moments across weddings, fashion and live events.",
    photoBlob: makeBlob("https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400"),
    order: BigInt(1),
  },
  {
    id: BigInt(2),
    name: "Priya Mehta",
    role: "Lead Photographer",
    bio: "Specialises in fashion and portrait photography with a bold editorial eye.",
    photoBlob: makeBlob("https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400"),
    order: BigInt(2),
  },
  {
    id: BigInt(3),
    name: "Arjun Das",
    role: "Video Editor",
    bio: "Expert in cinematic colour grading and storytelling through post-production.",
    photoBlob: makeBlob("https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400"),
    order: BigInt(3),
  },
  {
    id: BigInt(4),
    name: "Sneha Roy",
    role: "Cameraman & Editor",
    bio: "Versatile talent behind both the lens and the edit suite for social media content.",
    photoBlob: makeBlob("https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400"),
    order: BigInt(4),
  },
];

export const mockBackend = {
  addPortfolioItem: async (fileBlob, category, caption, description) => ({
    id: BigInt(Date.now()),
    createdAt: BigInt(Date.now()),
    fileBlob,
    caption,
    description,
    category,
  }),

  addTeamMember: async (name, role, photoBlob, bio, order) => ({
    id: BigInt(Date.now()),
    name,
    role,
    photoBlob,
    bio,
    order,
  }),

  assignCallerUserRole: async (_user: Principal, _role: UserRole) => undefined,

  deleteInquiry: async (_id: bigint) => true,

  deletePortfolioItem: async (_id: bigint) => true,

  deleteTeamMember: async (_id: bigint) => true,

  getCallerUserRole: async () => UserRole.guest,

  isCallerAdmin: async () => false,

  listInquiries: async (): Promise<Inquiry[]> => [],

  listPortfolioItems: async (category) => {
    if (category === null) return portfolioItems;
    return portfolioItems.filter((item) => item.category === category);
  },

  listTeamMembers: async () => teamMembers,

  markInquiryViewed: async (_id: bigint) => true,

  submitInquiry: async (input: InquiryInput): Promise<Inquiry> => ({
    id: BigInt(Date.now()),
    ...input,
    isViewed: false,
    createdAt: BigInt(Date.now()),
  }),

  updateTeamMember: async (_id: bigint, _name: string, _role: string, _photoBlob: ExternalBlob, _bio: string, _order: bigint) => true,

  getBrandingLogo: async () => null,

  setBrandingLogo: async (_blob: unknown) => undefined,
} as unknown as backendInterface;
