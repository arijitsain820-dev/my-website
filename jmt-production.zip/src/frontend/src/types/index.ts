import type { ExternalBlob, Timestamp } from "@/backend";

export { ServiceType, UserRole } from "@/backend";
export type {
  ExternalBlob,
  Timestamp,
  PortfolioItem,
  TeamMember,
  Inquiry,
  InquiryInput,
} from "@/backend";

export interface ServiceOption {
  value: string;
  label: string;
}

export const SERVICE_LABELS: Record<string, string> = {
  Wedding: "Wedding",
  Fashion: "Fashion",
  Concert: "Concert",
  Birthday: "Birthday",
  VideoEditing: "Video Editing",
  SocialMedia: "Social Media",
};

export function getImageUrl(blob: ExternalBlob | undefined | null): string {
  if (!blob) return "/assets/images/placeholder.svg";
  try {
    return blob.getDirectURL();
  } catch {
    return "/assets/images/placeholder.svg";
  }
}

export function formatTimestamp(ts: Timestamp): string {
  return new Date(Number(ts) / 1_000_000).toLocaleDateString("en-IN", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
